┌────────────────────────┐
│Hook-based Cell Motility│
└────────────────────────┘

This program is the second alternative to the CompuCell3D model.
While the code works it is still rather bare bones.
There are a few examples given of logic determining how the hooks will move as well as an action handler.


## Configuration ##
To configure the program, use the configuration.json file.
Here you can modify the names of the modules.


## Making your own modules ##
It is possible to make your own modules for the cell logic and the action handler.
There are two important python files containing functions. They can be same file.

### ACTION HANDLER ###
This module allows you to modify the action handler;
this will determine what actions the cell will take in what order.
Requires one function named "action_handler" which takes a cell object "cell" and the step number as input.
Then it can call upon the folllowing functions: 
	cell.new_protrusion(age) to start making a new protrusion with the age of age
	cell.move_core() to move the core according to the defined force functions.
	cell.age_protrusions(min_age) to age the protrusions and delete old ones.

### PROTRUSION ACTION ###
This module allows you to modify the behaviour the protrusions will have,
with regards to the formation and force of the protrusions.

There are four required functions:

will_continue(core_location, hook_location, step): This function takes the core location, hook location and step number to determine if the hook will continue forwards or stop. Should return a boolean.
will_hook(core_location, hook_location, step): Similar to will_continue, but to determine if the hook will be formed or discarded.

auxiliary_force(cell): A force that is applied to the cell core regardless of the protrusions.
protrusion_force(protrusion, cell): A force that each protrusion gives to the cell core.


## Additional files ##
A few additional files are included.
This includes a flowchart, which is meant to showcase how the program operates.
There's also a small diagram of what the program is meant to do.
There are gifs showing the provided examples.
Finally, there's a list of things that were worked on before the code got abandoned.

If there are questions, feel free to ask me at saya.smit@ru.nl