import numpy


def choose_direction() -> list:
	"""
	Pick a random direction to move to.
	Direction will be uniform on the 2-sphere.
	
	Arguments
	---------
	None

	Returns
	-------
	A dictionary that will be used to increment each step (x: x, y: y, z: z).
	"""
	#Take a random theta, uniformly on 0 to 2π.
	theta = numpy.random.uniform(0, 2*numpy.pi)
	#Take a random phi, with a probability density such that the eventual x, y, z are uniform
	phi = numpy.arccos(2*numpy.random.uniform() - 1)
	
	#Calculate step vector
	x = numpy.cos(theta) * numpy.sin(phi)
	y = numpy.sin(theta) * numpy.sin(phi)
	z = numpy.cos(phi)
	return {"x": x, "y": y, "z": z}



def move(old_location, step) -> list:
	"""
	Move the new protrusion hook in the desired direction.

	Arguments
	---------
	Old hook location of new protrusion
	Step vector

	Returns
	-------
	A 3-vector that will determine the new hook location (x, y, z).
	"""
	new_location = old_location
	for i in ["x", "y", "z"]:
		new_location[i] += step[i]
	return new_location


def create(core_location: dict, age: int = 0):
	"""
	Try to create a new protrusion.

	Arguments
	---------
	Core location

	Returns
	-------
	A tuple containing:
		has_hooked: Boolean status message, meaning if the protrusion has hooked or not;
		protrusion_object: If hooked, a protrusion class for the new protrusion. Else, None.
	"""
	hook_location = core_location.copy()
	step_vector = choose_direction()
	step_number = 0

	while True:
		hook_location = move(hook_location, step_vector)
		step_number += 1

		continues = will_continue(core_location, hook_location, step_number)
		if continues:
			continue

		hooks = will_hook(core_location, hook_location, step_number)
		if hooks:
			new_protrusion = Protrusion(hook_location, age)
			has_hooked = True
			return (has_hooked, new_protrusion)

		new_protrusion = None
		has_hooked = False
		return (has_hooked, new_protrusion)



#Placeholders for user definable functions.
def will_continue(core_location, hook_location, step_number) -> bool:
	"""
	Calculate whether or not a newly created protrusion should go further.
	
	Arguments
	---------
	Core locations
	Current protrusion hook location
	Continue probability field calculation
	Any additional user-defined variables

	Returns
	-------
	A boolean, determining if the protrusion will go out further.
	On TRUE, the new protrustion will go another step ahead.
	On FALSE, it should be determined wether or not the protrusion will hook or discard.
	"""
	#Should be overwritten by the imported function. This will be a blank function just returning False.
	return False


def will_hook(core_location, hook_location, step_number) -> bool:
	"""
	Calculate whether or not a newly created protrusion will hook onto the field.
	
	Arguments
	---------
	Core location
	Current protrusion hook location
	Hook probability field calculation
	Any additional user-defined variables

	Returns
	-------
	A boolean, determining it the protrusion will hook.
	On TRUE, a new protrustion will be made.
	On FALSE, the potential protrusion will be discarded.
	"""
	#Should be overwritten by the imported function. This will be a blank function just returning False.
	return False


def auxiliary_force(cell):
	"""
	A force applied to the cell core, regardless of protrusion.

	Arguments
	---------
	Cell object

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	#Should be overwritten by the imported function. This will be a blank function just returning (0, 0, 0).
	return numpy.array((0, 0, 0))
	

def protrusion_force(protrusion, cell):
	"""
	The force a single protrusion has on the cell core.

	Arguments
	---------
	Individual protrusion to be calculated
	Cell object

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	#Should be overwritten by the imported function. This will be a blank function just returning (0, 0, 0).
	return numpy.array((0, 0, 0))

default_min_age = 0




class Protrusion:
	"Class for protrusion related things"
	"""
	Need to keep track off:
		Hook x, y, z
		Age
	"""
	def __init__(self, hook_location, age = 0):
		"Create a new protrusion."
		#Choose the direction
			#Move in the direction
			#If continue, move again and repeat.
		#Else if hook, hook the new protrusion.
		#Else, discard the protrusion.
		self.x = hook_location["x"]
		self.y = hook_location["y"]
		self.z = hook_location["z"]
		self.age = age

	def __getitem__(self, key):
		return {"x": self.x, "y": self.y, "z": self.z}[key]
	
	def __str__(self):
		return str(self.make_dictionary())
	
	
	def make_dictionary(self):
		return {"x": self.x, "y": self.y, "z": self.z}
	
	def make_vector(self):
		"Make a numpy vector (x, y, z)."
		return numpy.array([self.x, self.y, self.z])


	def decrement_age(self, min_age: int = None) -> str:
		"""
		Subtract 1 to the age of the protrusion.
		
		Arguments
		---------
		self: The protrusion to age.
		min_age: How old this protrusion can be at most.

		Returns
		-------
		A status message:
			"Alive": Cell age is higher than min age. Protrusion needs to keep existing.
			"Dead": Cell age is less or equal than max age. Protrusion should stop.
		"""
		if min_age is None:
			min_age = default_min_age
			
		self.age -= 1
		if self.age >= min_age:
			return "Alive"
		return "Dead"


	# def increment_age(self, max_age: int) -> str:
	# 	"""
	# 	Add to the age of the protrusion.
		
	# 	Arguments
	# 	---------
	# 	self: The protrusion to age.
	# 	max_age: How old this protrusion can be at most.

	# 	Returns
	# 	-------
	# 	A status message:
	# 		"Alive": Cell age is less than max age. Protrusion needs to keep existing.
	# 		"Dead": Cell age is higher than max age. Protrusion should stop.
	# 	"""
	# 	self.age += 1
	# 	if self.age <= max_age:
	# 		return "Alive"
	# 	return "Dead"
	
	def calculate_distance(self, cell) -> float:
		"""
		Calculate the distance of this protrusion to the cell core.

		Arguments
		---------
		The protrusion
		Cell core location

		Returns
		-------
		The distance as a float.
		"""
		x = self["x"] - cell["x"]
		y = self["y"] - cell["y"]
		z = self["z"] - cell["z"]

		return numpy.sqrt(x**2 + y**2 + z**2)
	
	def calculate_direction_vector(self, cell): ##This might lead to a circular import. For now, should be fine.
		"""
		Calculate the unit vector in the direction of this protrusion from the cell core.

		Arguments
		---------
		The protrusion
		Cell core location

		Returns
		-------
		A numpy vector with the force values (x, y, z).
		"""
		direction: numpy.array = self.make_vector() - cell.make_vector()
		if numpy.linalg.norm(direction) == 0:
			return numpy.array([0, 0, 0])
		return direction / numpy.linalg.norm(direction)

	
	



def main():
	"Main function, mostly for testing."
	# import matplotlib.pyplot as plot
	# figure = plot.figure().add_subplot(projection = "3d")

	# for _ in range(200):
	# 	[x, y, z] = choose_direction()
	# 	figure.scatter(x, y, z, c = "m")
	# plot.show()
	print(create({"x": 0, "y": 0, "z": 0}))
	pass


if __name__ == "__main__":
	main()
	