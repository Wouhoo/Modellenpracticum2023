# Example probability field.
# This one will model a wall;
# The protrusion will hook onto a wall at y = 75
# It will hook if and only if it actually hits the wall.
# There will always be a force to -y to prevent it sticking to the wall.
# The protrusion cannot exceed a distance of 250.
# Toggleable: Protrusion must be above core.

import numpy
try:
	import cell
except ImportError:
	# Ignore.
	# cell import is only really used for the IDE. Has no actual effect on the program, if done properly that is.
	pass

#Add any variables to be read or written to in the functions here.
wall_distance = 75
max_core_distance = 250
force_above_core = True


def will_continue(core_location: cell.Cell, hook_location: cell.Cell, step) -> float:
	"""
	Logic to determine if the protrusion will go on.
	
	Arguments
	---------
	Core location (x, y, z)
	Current protrusion hook location (x, y, z)
	Step number; is also distance to core
	Any additional user defined variables.

	Returns
	-------
	A boolean deciding if the hook will continue;
		On TRUE, the new protrustion will go another step ahead.
		On FALSE, it should be determined wether or not the protrusion will hook or discard.
	"""
	inside_wall   = hook_location["y"] < wall_distance
	closeby_core  = (step <= max_core_distance)
	if force_above_core:
		above_core = hook_location["z"] + 25 >= core_location["z"]
	else: above_core = True

	if inside_wall and closeby_core and above_core:
		return True
	return False


def will_hook(core_location, hook_location, step):
	"""
	Logic to determine whether or not the protrusion will hook.
	
	Arguments
	---------
	Core location
	Current protrusion hook location
	Step number; is also distance to core
	Any additional user defined variables. (NOT IMPLEMENTED)

	Returns
	-------
	A boolean deciding if the hook will continue.
		On TRUE, the new protrustion will go another step ahead.
		On FALSE, it should be determined wether or not the protrusion will hook or discard.
	"""
	inside_wall   = hook_location["y"] < wall_distance
	return not inside_wall


def auxiliary_force(cell):
	"""
	A force applied to the cell core, regardless of protrusion.

	Arguments
	---------
	Cell object

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	return -numpy.array((0, cell.core_y, 0)) / 50
	


def protrusion_force(protrusion, cell):
	"""
	The force a single protrusion has on the cell core.

	Arguments
	---------
	Individual protrusion to be calculated
	Cell object

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	direction = protrusion.calculate_direction_vector(cell)
	magnitude = protrusion.calculate_distance(cell) / 50
	return direction * magnitude