import numpy
#Example probability field.
#This one will model a tube;
#The protrusion will hook onto a tube of radius 100 in the x, y direction.
#It will hook if and only if it actually hits the tube.
#The protrusion cannot exceed a distance of 250.
#Toggleable: Protrusion must be above core.

tube_radius = 100
max_core_distance = 250
force_above_core = True

def will_continue(core_location, hook_location, step) -> float:
	"""
	Logic to determine if the protrusion will go on.
	
	Arguments
	---------
	Core location (x, y, z)
	Current protrusion hook location (x, y, z)
	Step number; is also distance to core
	Any additional user defined variables.

	Returns
	-------
	A boolean deciding if the hook will continue;
		On TRUE, the new protrustion will go another step ahead.
		On FALSE, it should be determined wether or not the protrusion will hook or discard.
	"""
	inside_tube = numpy.sqrt(hook_location["x"]**2 + hook_location["y"]**2) < tube_radius
	closeby_core = step <= max_core_distance
	if force_above_core:
		above_core = hook_location["z"] + 25 >= core_location["z"]

	else:
		above_core = True

	return inside_tube and closeby_core and above_core


def will_hook(core_location, hook_location, step):
	"""
	Logic to determine whether or not the protrusion will hook.
	
	Arguments
	---------
	Core location
	Current protrusion hook location
	Step number; is also distance to core
	Any additional user defined variables. (NOT IMPLEMENTED)

	Returns
	-------
	A boolean deciding if the hook will continue.
		On TRUE, the new protrustion will go another step ahead.
		On FALSE, it should be determined wether or not the protrusion will hook or discard.
	"""
	inside_tube = numpy.sqrt(hook_location["x"]**2 + hook_location["y"]**2) < tube_radius
	return not inside_tube


def auxiliary_force(cell):
	"""
	A force applied to the cell core, regardless of protrusion.

	Arguments
	---------
	Cell object

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	return numpy.array((0, 0, 0))
	


def protrusion_force(protrusion, cell):
	"""
	The force a single protrusion has on the cell core.

	Arguments
	---------
	Individual protrusion to be calculated
	Cell object

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	direction = protrusion.calculate_direction_vector(cell)
	magnitude = protrusion.calculate_distance(cell) / 50
	return direction * magnitude
