import numpy
try:
	import cell
except ImportError:
	# Ignore.
	# cell import is only really used for the IDE. Has no actual effect on the program, if done properly that is.
	pass


def action_handler(cell: cell.Cell, step: int):
	"""
	Manages what actions the cell will perform during a single cycle.

	Parameters
	----------
	cell: The cell object this action handler will handle.
	step: The step number.

	Can call upon the folllowing functions: 
		cell.new_protrusion(age) to start making a new protrusion with the age of age
		cell.move_core() to move the core according to the defined force functions.
		cell.age_protrusions(min_age) to age the protrusions and delete old ones.
	"""
	#Will simply go:
	# Create protrusion
	# Move core
	# Increment ages up to 10
	has_hooked = cell.new_protrusion(age=20)
		
	cell.move_core()
	
	cell.age_protrusions(numpy.random.randint(0, 10))