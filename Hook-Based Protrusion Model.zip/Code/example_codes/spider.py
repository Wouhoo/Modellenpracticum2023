import numpy
###NEEDS WORK

#Example probability field.
#This one will model a spider;
#With eight legs it will alternate between left leg and right leg.
#The legs will walk along the floor.
#The force will not move towards or away from the floor.
#The protrusion cannot exceed a distance of 250.
#Toggleable: Protrusion must be above core.

floor_level = -50
max_core_distance = 200
on_left_side = True


def will_continue(core_location, hook_location, step) -> float:
	"""
	Logic to determine if the protrusion will go on.
	
	Arguments
	---------
	Core location (x, y, z)
	Current protrusion hook location (x, y, z)
	Step number; is also distance to core
	Any additional user defined variables.

	Returns
	-------
	A boolean deciding if the hook will continue;
		On TRUE, the new protrustion will go another step ahead.
		On FALSE, it should be determined wether or not the protrusion will hook or discard.
	"""
	#See if on correct side.
	#Legs must point down.
	if hook_location["z"] > core_location["z"]:
		return False
	
	#And forwards.
	if hook_location["y"] < core_location["y"]:
		return False
	
	#Must be on correct side.
	if on_left_side:
		if hook_location["x"] < core_location["x"]:
			return False
	else:
		if hook_location["x"] > core_location["x"]:
			return False
	
	#Continue until hitting floor.
	if hook_location["z"] < floor_level:
		return False
	
	#Make sure it's not too far away.
	if step > max_core_distance:
		return False

	return True


def will_hook(core_location, hook_location, step):
	"""
	Logic to determine whether or not the protrusion will hook.
	
	Arguments
	---------
	Core location
	Current protrusion hook location
	Step number; is also distance to core
	Any additional user defined variables. (NOT IMPLEMENTED)

	Returns
	-------
	A boolean deciding if the hook will continue.
		On TRUE, the new protrustion will go another step ahead.
		On FALSE, it should be determined wether or not the protrusion will hook or discard.
	"""
	if hook_location["z"] < floor_level:
		global on_left_side
		on_left_side = not on_left_side		#Swap sides
		return True
	return False


def auxiliary_force(cell):
	"""
	A force applied to the cell core, regardless of protrusion.

	Arguments
	---------
	Cell object

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	return numpy.array((0, 0, 0))
	


def protrusion_force(protrusion, cell):
	"""
	The force a single protrusion has on the cell core.

	Arguments
	---------
	Individual protrusion to be calculated 
	Cell object 

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	return numpy.array([
		protrusion["x"] - cell["x"],
		protrusion["y"] - cell["y"],
		0
	]) / 50


def action_handler(cell, step):
	has_hooked = False
	while not has_hooked:
		has_hooked = cell.new_protrusion(age = 8)
	
	cell.move_core()
	cell.age_protrusions()