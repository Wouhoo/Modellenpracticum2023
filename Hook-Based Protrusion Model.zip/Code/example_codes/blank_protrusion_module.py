import numpy

some_global_variable = "Some Value"

def will_continue(core_location, hook_location, step) -> float:
	"""
	Logic to determine if the protrusion will go on.
	
	Arguments
	---------
	Core location (x, y, z)
	Current protrusion hook location (x, y, z)
	Step number; is also distance to core

	Returns
	-------
	A boolean deciding if the hook will continue;
		On TRUE, the new protrustion will go another step ahead.
		On FALSE, it should be determined wether or not the protrusion will hook or discard.
	"""
	return False



def will_hook(core_location, hook_location, step):
	"""
	Logic to determine whether or not the protrusion will hook.
	
	Arguments
	---------
	Core location
	Current protrusion hook location
	Step number; is also distance to core

	Returns
	-------
	A boolean deciding if the hook will continue.
		On TRUE, the new protrustion will go another step ahead.
		On FALSE, it should be determined wether or not the protrusion will hook or discard.
	"""
	return False



def auxiliary_force(cell):
	"""
	A force applied to the cell core, regardless of protrusion.

	Arguments
	---------
	Cell object

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	return numpy.array((0, 0, 0))
	


def protrusion_force(protrusion, cell):
	"""
	The force a single protrusion has on the cell core.

	Arguments
	---------
	Individual protrusion to be calculated
	Cell object

	Returns
	-------
	A numpy vector or dictionary with force values.
	"""
	return numpy.array((0, 0, 0))
