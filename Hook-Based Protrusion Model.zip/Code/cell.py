import numpy
import protrusion


class Cell:
	"Class for all cell-related things."
	"""
	Need to keep track off:
		Core x, y, z
		All protrusions of this cell
	"""
	def __init__(self, location = [0, 0, 0]):
		"Create a cell object."
		#Create core.
		self.core_x = location[0]
		self.core_y = location[1]
		self.core_z = location[2]

		self.core = self.make_dictionary()

		#Make empty protrusion dictionary.
		self.protrusions = {}
		self.protrusion_count_total = 0

	def __getitem__(self, key):
		return {"x": self.core_x, "y": self.core_y, "z": self.core_z}[key]
	
	def make_dictionary(self) -> dict:
		return {"x": self.core_x, "y": self.core_y, "z": self.core_z}
	
	def make_vector(self):
		"Make a numpy vector (x, y, z)."
		return numpy.array([self.core_x, self.core_y, self.core_z])


	def new_protrusion(self, age: int = 0) -> bool:
		"""
		Make a new protrusion step.

		Arguments
		---------
		Cell object
		Age: The age the new protrusion should be.

		Returns
		-------
		On success, adds the new protrusion to the protrusion list.
		Returns hooked status.
		"""
		print(f"Trying to make a new protrusion.")
		has_hooked, new_protrusion = protrusion.create(self.core, age)
		if has_hooked:
			self.protrusions[self.protrusion_count_total] = new_protrusion
			self.protrusion_count_total += 1
			print(f"Succesfully made a new hook at {new_protrusion} with age {age}")			
		else:
			print(f"Did not make a new hook.")
		return has_hooked
	

	def move_core(self):
		"Move the core."
		print(f"Moving cell from {self.core}")
		force = dict()
		#Calculate the auxiliary force.
		force["Auxiliary"] = protrusion.auxiliary_force(self)

		#Calculate the force of all protrusions.
		for key, item in self.protrusions.items():
			force[key] = protrusion.protrusion_force(item, self)
		
		total_force = sum(force.values())
		try:
			self.core_x += total_force[0]
			self.core_y += total_force[1]
			self.core_z += total_force[2]
			self.core = self.make_dictionary()
		except TypeError:		#If there are zero forces.
			pass
		print(f"Moved to {self.core}")
		return None


	def age_protrusions(self, min_age: int = 0):
		"Decrement all ages."
		print(f"Aging protrusions")
		status = dict()
		#Update the age of all protrusions, which will delete old ones.
		for key, item in self.protrusions.items():
			status[key] = item.decrement_age(min_age)

		for key, item in status.items():
			if item == "Dead":
				del self.protrusions[key]
		print(f"Aged protrusions.")
		return None


	# def age_protrusions(self, max_age):
	# 	"Increment all ages."
	# 	print(f"Aging protrusions")
	# 	status = dict()
	# 	#Update the age of all protrusions, which will delete old ones.
	# 	for key, item in self.protrusions.items():
	# 		status[key] = item.increment_age(max_age)

	# 	for key, item in status.items():
	# 		if item == "Dead":
	# 			del self.protrusions[key]
	# 	print(f"Aged protrusions.")
	# 	return None





def main():
	"Main function, mostly for testing."
	print("Nothing implemented.")
	pass

if __name__ == "__main__":
	main()