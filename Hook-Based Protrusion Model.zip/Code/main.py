try:	#Import basic modules
	import matplotlib
	import matplotlib.pyplot 	as plot
	import matplotlib.animation as animation
	import numpy
	import json
	import importlib
except ImportError:
	raise ImportError("Error importing the modules! Are Matplotlib and Numpy installed?")

try:	#Import additional files
	from cell import Cell
	import protrusion
except ImportError:
	raise ImportError("Could not find cell.py or protrusion.py! Make sure these are in the same folder as this file (main.py).")



def draw_frame(cell: Cell, frame):
	figure = plot.figure()
	three_d = figure.add_subplot(projection = "3d")

	three_d.set_xlim(-125, 125)
	three_d.set_ylim(-125, 125)
	three_d.set_zlim(-125, 125)

	three_d.set_xlabel("X")
	three_d.set_ylabel("Y")
	three_d.set_zlabel("Z")

	core_x, core_y, core_z = cell.make_vector()
	three_d.scatter(core_x, core_y, core_z, c = "b", s = 100)

	for i in range(-150, 200, 50):
		# three_d.plot([-150, 150], [75, 75], [i, i], c = "k")
		# three_d.plot([i, i], [75, 75], [-150, 150], c = "k")
		three_d.plot([-150, 150], [i, i], [-50, -50], c = "k")
		three_d.plot([i, i], [-150, 150], [-50, -50], c = "k")

	# x = 100*numpy.cos(numpy.arange(0, 2*numpy.pi + numpy.pi/10, numpy.pi/10))
	# y = 100*numpy.sin(numpy.arange(0, 2*numpy.pi + numpy.pi/10, numpy.pi/10))
	# z = [core_z] * 21
	# three_d.plot(x, y, z, c = "k")

	# x = 100*numpy.cos(numpy.arange(0, 2*numpy.pi + numpy.pi/10, numpy.pi/10))
	# y = 100*numpy.sin(numpy.arange(0, 2*numpy.pi + numpy.pi/10, numpy.pi/10))
	# z = [core_z + 25] * 21
	# three_d.plot(x, y, z, c = "k")

	# x = 100*numpy.cos(numpy.arange(0, 2*numpy.pi + numpy.pi/10, numpy.pi/10))
	# y = 100*numpy.sin(numpy.arange(0, 2*numpy.pi + numpy.pi/10, numpy.pi/10))
	# z = [core_z - 25] * 21
	# three_d.plot(x, y, z, c = "k")

	three_d.plot([0, 0], [0, 0], [-200, 200], c = "m")

	for key, item in cell.protrusions.items():
		x, y, z = item.make_vector()
		three_d.scatter(x, y, z, c = "g")
		three_d.plot([core_x, x], [core_y, y], [core_z, z], c = "r")
		
		# ring_x = 100*numpy.cos(numpy.arange(0, 2*numpy.pi + numpy.pi/10, numpy.pi/10))
		# ring_y = 100*numpy.sin(numpy.arange(0, 2*numpy.pi + numpy.pi/10, numpy.pi/10))
		# ring_z = [z] * 21
		# three_d.plot(ring_x, ring_y, ring_z, c = "k")

	# plot.show()
	print(f"Saving frame {frame}")
	plot.savefig(f"image_outputs/{frame // 3}")
	return None


def main():
	#Load configuration block.
	try:
		with open("configuration.json") as configuration_file:
			configuration = json.load(configuration_file)
	except FileNotFoundError:
		raise FileNotFoundError("Could not find the configuration.json file!")
	
	should_log: bool 		= configuration["Logging"]
	protrusion.min_age: int = configuration["Min age"]
	
	try:
		action_handler_name: str = configuration["Modules"]["Action handler module"]
		action_handler_name 	 = action_handler_name.replace("/", ".")						#Imported modules must have folders with dot. For ease of use, any / or \ will be converted.
		action_handler_name  	 = action_handler_name.replace("\\", ".")
		action_handler_name  	 = action_handler_name.replace(".py", "")
		action_handler_module 	 = importlib.import_module(action_handler_name)
		action_handler: function = action_handler_module.action_handler
	except ImportError:
		raise ImportError(f"Could not find the module acion_handler given by {action_handler_name}.")
	except KeyError:
		raise KeyError(f"Error in the configuration file: Module:Action handler module does not exist.")
	except AttributeError:
		raise AttributeError(f"Error in parsing action handler: Not found in module {action_handler_name}")
	
	try:
		protrusion_actions_name: str	= configuration["Modules"]["Protrusion actions module"]
		protrusion_actions_name			= protrusion_actions_name.replace("/", ".")				#Imported modules must have folders with dot. For ease of use, any / or \ will be converted.
		protrusion_actions_name			= protrusion_actions_name.replace("\\", ".")
		protrusion_actions_module 		= importlib.import_module(protrusion_actions_name)

		protrusion.will_continue 		= protrusion_actions_module.will_continue
		protrusion.will_hook     		= protrusion_actions_module.will_hook
		protrusion.protrusion_force		= protrusion_actions_module.protrusion_force
		try:
			protrusion.auxiliary_force  = protrusion_actions_module.auxiliary_force
		except NameError:
			print(f"[WARNING] No auxiliary force found. Using default version.")

	except ImportError:
		raise ImportError(f"Could not find the module protrusion_actions given by {protrusion_actions_name}.")
	except KeyError:
		raise KeyError(f"Error in the configuration file: [Module:Protrusion actions module] does not exist.")

	

	#Perform actions group.
	my_cell = Cell()
	step = 0
	while step < 100:		#Bad python but who cares?
		print(f"\nStep {step}")
		action_handler(my_cell, step)
		if step % 3 == 0:
			draw_frame(my_cell, step)
		step += 1
	


if __name__ == "__main__":
	main()


"""
Copyright (c) 2023 Lily Saya Smit

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
"""