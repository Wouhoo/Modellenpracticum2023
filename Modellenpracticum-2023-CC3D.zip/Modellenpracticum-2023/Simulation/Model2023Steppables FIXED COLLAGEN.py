import numpy as np
import random
from datetime import datetime
from cc3d.core.PySteppables import *

def drawDDA(x1,y1,x2,y2):
    pixList=[]
    x,y = x1,y1
    length = (x2-x1) if abs(x2-x1) > abs(y2-y1) else (y2-y1)
    dx = (x2-x1)/float(length)
    dy = (y2-y1)/float(length)
    pixList.append((int(x),int(y)))
    for i in range(abs(length)):
        x += dx
        y += dy
        pixList.append((int(x),int(y)))
    return pixList
   
class CC3D_fibersSteppable(SteppableBasePy):
    def __init__(self,frequency=1):
        SteppableBasePy.__init__(self,frequency)
    
    def start(self):
        import random
        import math        
        # parameters for generating the fibers
        lx = self.dim.x #window x width
        ly = self.dim.y #window y width
        v = 50  #number of fibers 
        fl = 40. #length of the fibers in pixels
        
        #random.seed(12) #to test the same network multiple times if desired
        #some suggested numbers: 12 for a hole at the start for the cell to squeeze through,
        #15 for a track with a vertical hole
        
        # for every number in the number of fibers, now create a fiber        
        for i in range(v):
            cell = self.new_cell(self.COLLAGEN)  # create a new cell for this fiber
            pixList=[]
            m = int(lx*random.random())
            n = int(ly*random.random())
            while 20 < m and m < 60:    # make it so the area where the cell spawns remains mostly clear of fibers (so the cell can be created properly)
                m = int(lx*random.random())
            while ly//2 - 18 < n and n < ly//2 + 18:
                n = int(ly*random.random())
            theta = 2*math.pi*random.random()
            x = int(m+fl*math.cos(theta))
            y = int(n+fl*math.sin(theta))
            print(i, x,m, y,n)
            pixList=drawDDA(x,y, m,n)
            if len(pixList) > 0:
                for (px,py) in pixList:
                    px=min(max(px,0),lx-1)  # 0 <= px <= lx-1
                    py=min(max(py,0),ly-1)  # 0 <= py <= ly-1
                    self.cell_field[px:px+1, py:py+1, 0] = cell # add this pixel to the cell
            cell.targetVolume = cell.volume  # the .xml says this cell type is frozen, 
            cell.lambdaVolume = 10000        # so this doesn't matter

    def step(self,mcs):
        if mcs == 10:
            for cell in self.cell_list:
                print("cell.id=",cell.id," volume=",cell.volume)

    def finish(self):
        pass

class Model2023Steppable(SteppableBasePy):
    def __init__(self,frequency=1):
        SteppableBasePy.__init__(self,frequency)
        # References to cell types
        self.typeCollagen = 1
        self.typeTumor = 2
        self.typeNucleus = 3
        self.typeMembrane = 4
        
        # Initialize cell references
        self.myTumor = None
        self.myNucleus = None
        self.myMembrane = None
        
        # Volume atributes of the tumor, nucleus and membrane
        self.tumorTargetVolume = 3000
        self.tumorLambdaVolume = 10
        self.nucleusTargetVolume = 350 # Supposed to be about 10 procent of total target volume
        self.nucleusLambdaVolume = 20
        self.membraneTargetVolume = 700
        self.membraneLambdaVolume = 5
        
        # Neighbor order of 'get_pixel_neighbors_based_on_neighbor_order'
        self.BoundaryPixelNeighborOrder = 1
        
        # Clustering counting variable
        self.collagenClusterCounter = 0
        
        # Name & location of the log file
        fileName = 'MyLog'
        filePath = 'C:\\Users\\Wouter\\Documents\\Modellenpracticum\\Modellenpracticum-2023\\Simulation' # Adjustable! #*** Dit nog verbeteren
        
        # Open log file
        fileLoc = '/'.join([filePath, fileName + '.piff'])
        self.myFile = open(fileLoc, 'w')
        currentTime = datetime.now()
        printTime = currentTime.strftime("%H:%M:%S")
        self.printLog('Steppable initialized on', printTime)

    # Print to log file
    def printLog(self, *args):
        for arg in args:
            self.myFile.write(str(arg) + ' ')
        self.myFile.write('\n')

    # Print array to log file
    def printLogArr(self, arr):
        for elm in arr:
            self.printLog(elm)
    
    # Translates type id to type name
    def typeToName(self, type):
        return ['Medium', 'Collagen', 'Tumor', 'Nucleus', 'Membrane'][type]
    
    '''
    # Create a chemical field with a linear gradient by creating a single line at the right border and letting it diffuse
    def ChemFieldCreatorV2(self, field_strength):
        for y in range(self.dim.y):
            self.field.ChemField[self.dim.x-1,y,0] = field_strength
            
    This version (which sets the field strength for every pixel) turns out to crash CC3D lol, please don't use it
    def ChemFieldCreator(self, max_field_strength, no_of_steps):
        field_strength = 0
        for x in range(self.dim.x):
            for y in range(self.dim.y):
                self.field.ChemField[x,y,0] = field_strength
            if x % (self.dim.x/no_of_steps) == 0:
                field_strength += max_field_strength/no_of_steps
    '''
            
    # Create a track with an adjustable narrowing    
    def CollagenCreator(self, upper_x,upper_y,lower_x,lower_y):
        # Fixed dimensions of the start of the track
        fixed_width = 100
        fixed_height = 50
        
        # Create all upper track elements
        collagen_upper_fixed = self.new_cell(self.typeCollagen) # Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2+fixed_height//2, 0] = collagen_upper_fixed
        
        collagen_upper_x = self.new_cell(self.typeCollagen) # Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-upper_x:self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_x
       
        collagen_upper_x_left = self.new_cell(self.typeCollagen) # Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-upper_x, self.dim.y//2+fixed_height//2, 0] = collagen_upper_x_left
        
        # Distinct between a narrowing and a widening
        if upper_y > 0:
            collagen_upper_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2+fixed_height//2:self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_y
            
            collagen_upper_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-upper_x, self.dim.y//2+fixed_height//2:self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_y_left
        else:
            collagen_upper_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2, 0] = collagen_upper_y
            
            collagen_upper_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-upper_x, self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2, 0] = collagen_upper_y_left      
        
        # Assign the same cluster id to all upper track elements
        self.reassign_cluster_id(collagen_upper_fixed, 0)
        self.reassign_cluster_id(collagen_upper_x, 0)
        self.reassign_cluster_id(collagen_upper_x_left, 0)
        self.reassign_cluster_id(collagen_upper_y, 0)
        self.reassign_cluster_id(collagen_upper_y_left, 0)
        
        # Create all lower track elements
        collagen_lower_fixed = self.new_cell(self.typeCollagen) # Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2-fixed_height//2, 0] = collagen_lower_fixed
        
        collagen_lower_x = self.new_cell(self.typeCollagen) # Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-lower_x:self.dim.x-fixed_width, self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_x
        
        collagen_lower_x_left = self.new_cell(self.typeCollagen) # Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-lower_x, self.dim.y//2-fixed_height//2, 0] = collagen_lower_x_left
        
        # Distinct between a narrowing and a widening
        if lower_y > 0:
            collagen_lower_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2-fixed_height//2-lower_y:self.dim.y//2-fixed_height//2, 0] = collagen_lower_y
            
            collagen_lower_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-lower_x, self.dim.y//2-fixed_height//2-lower_y:self.dim.y//2-fixed_height//2, 0] = collagen_lower_y_left
        else:
            collagen_lower_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2-fixed_height//2:self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_y
            
            collagen_lower_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-lower_x, self.dim.y//2-fixed_height//2:self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_y_left      
        
        # Assign the same cluster id to all lower track elements
        self.reassign_cluster_id(collagen_lower_fixed, 1)
        self.reassign_cluster_id(collagen_lower_x, 1)
        self.reassign_cluster_id(collagen_lower_x_left, 1)
        self.reassign_cluster_id(collagen_lower_y, 1)
        self.reassign_cluster_id(collagen_lower_y_left, 1)
        
    # Create a track that is diagonal at the end of the narrowing    
    def DiagonalCollagenCreator(self):
        # Set all dimensions
        fixed_width = 100
        fixed_height = 50
        upper_x = 100
        upper_y = -10
        lower_x = 100
        lower_y = -10
        
        # Create all upper track elements
        collagen_upper_fixed = self.new_cell(self.typeCollagen) # Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2+fixed_height//2, 0] = collagen_upper_fixed
        
        collagen_upper_x = self.new_cell(self.typeCollagen) # Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-upper_x:self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_x
       
        collagen_upper_x_left = self.new_cell(self.typeCollagen) # Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-upper_x-10, self.dim.y//2+fixed_height//2, 0] = collagen_upper_x_left
        
        
        collagen_upper_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
        self.cell_field[self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2, 0] = collagen_upper_y
        
        # Create all steps at the end of the narrowing
        collagen_upper_step1 = self.new_cell(self.typeCollagen) 
        self.cell_field[self.dim.x-fixed_width-upper_x-2:self.dim.x-fixed_width-upper_x,self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2+upper_y+2,0] = collagen_upper_step1
        
        collagen_upper_step2 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-4:self.dim.x-fixed_width-upper_x-2,self.dim.y//2+fixed_height//2+upper_y+2:self.dim.y//2+fixed_height//2+upper_y+4,0] = collagen_upper_step2
        
        collagen_upper_step3 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-6:self.dim.x-fixed_width-upper_x-4,self.dim.y//2+fixed_height//2+upper_y+4:self.dim.y//2+fixed_height//2+upper_y+6,0] = collagen_upper_step3
        
        collagen_upper_step4 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-8:self.dim.x-fixed_width-upper_x-6,self.dim.y//2+fixed_height//2+upper_y+6:self.dim.y//2+fixed_height//2+upper_y+8,0] = collagen_upper_step4
        
        collagen_upper_step5 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-10:self.dim.x-fixed_width-upper_x-6,self.dim.y//2+fixed_height//2+upper_y+8:self.dim.y//2+fixed_height//2+upper_y+10,0] = collagen_upper_step5
        
        # Assign the same cluster id to all upper track elements
        self.reassign_cluster_id(collagen_upper_fixed, 0)
        self.reassign_cluster_id(collagen_upper_x, 0)
        self.reassign_cluster_id(collagen_upper_x_left, 0)
        self.reassign_cluster_id(collagen_upper_y, 0)
        self.reassign_cluster_id(collagen_upper_step1, 0)
        self.reassign_cluster_id(collagen_upper_step2, 0)
        self.reassign_cluster_id(collagen_upper_step3, 0)
        self.reassign_cluster_id(collagen_upper_step4, 0)
        self.reassign_cluster_id(collagen_upper_step5, 0)
        
        
        # Create all lower track elements
        collagen_lower_fixed = self.new_cell(self.typeCollagen) # Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2-fixed_height//2, 0] = collagen_lower_fixed
        
        collagen_lower_x = self.new_cell(self.typeCollagen) # Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-lower_x:self.dim.x-fixed_width, self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_x
        
        collagen_lower_x_left = self.new_cell(self.typeCollagen) # Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-lower_x-10, self.dim.y//2-fixed_height//2, 0] = collagen_lower_x_left
        
        
        collagen_lower_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
        self.cell_field[self.dim.x-fixed_width, self.dim.y//2-fixed_height//2:self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_y
        
        # Create all steps at the end of the narrowing 
        collagen_lower_step1 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-2:self.dim.x-fixed_width-lower_x,self.dim.y//2-fixed_height//2-lower_y-2:self.dim.y//2-fixed_height//2-lower_y,0] = collagen_lower_step1
        
        collagen_lower_step2 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-4:self.dim.x-fixed_width-lower_x-2,self.dim.y//2-fixed_height//2-lower_y-4:self.dim.y//2-fixed_height//2-lower_y-2,0] = collagen_lower_step2
        
        collagen_lower_step3 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-6:self.dim.x-fixed_width-lower_x-4,self.dim.y//2-fixed_height//2-lower_y-6:self.dim.y//2-fixed_height//2-lower_y-4,0] = collagen_lower_step3
        
        collagen_lower_step4 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-8:self.dim.x-fixed_width-lower_x-6,self.dim.y//2-fixed_height//2-lower_y-8:self.dim.y//2-fixed_height//2-lower_y-6,0] = collagen_lower_step4
        
        collagen_lower_step5 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-10:self.dim.x-fixed_width-lower_x-6,self.dim.y//2-fixed_height//2-lower_y-10:self.dim.y//2-fixed_height//2-lower_y-8,0] = collagen_lower_step5
         
        # Assign the same cluster id to all lower track elements
        self.reassign_cluster_id(collagen_lower_fixed, 1)
        self.reassign_cluster_id(collagen_lower_x, 1)
        self.reassign_cluster_id(collagen_lower_x_left, 1)
        self.reassign_cluster_id(collagen_lower_y, 1)
        self.reassign_cluster_id(collagen_lower_step1, 1)
        self.reassign_cluster_id(collagen_lower_step2, 1)
        self.reassign_cluster_id(collagen_lower_step3, 1)
        self.reassign_cluster_id(collagen_lower_step4, 1)
        self.reassign_cluster_id(collagen_lower_step5, 1)
        
            
    # Create various tracks with different dimensions
    def CollagenTrack(self, tracknumber):
        # y values may not exceed 55
        # x values may not exceed 300
        # Input are the dimensions of the narrowing= upper_x,upper_y,lower_x,lower_y 
        
        # Straight tube
        if tracknumber == 1: 
            self.CollagenCreator(0,0,0,0)
        # Upper indent
        elif tracknumber == 2:
            self.CollagenCreator(100,-30,0,0)
        # Lower indent
        elif tracknumber == 3:
            self.CollagenCreator(0,0,100,-12)
        # Upper and lower indent
        elif tracknumber == 4:
            self.CollagenCreator(150,-10,150,-10)
        # Upper and lower indent shifted
        elif tracknumber == 5:
            self.CollagenCreator(100,-12,150,-12)
        # Sharp upper and lower indent
        elif tracknumber == 6:
            self.CollagenCreator(10,-15,10,-15)
        # Broadening
        elif tracknumber == 7:
            self.CollagenCreator(300,5,300,5)
        # Diagonal version of track 4
        elif tracknumber == 8:
            self.DiagonalCollagenCreator()
        
    
    def start(self):   
        #Create the chemical field
        #self.ChemFieldCreator(10000, 4)
        
        #Create a collagen track
        #self.CollagenTrack(4) # Adjustable!
            
        # Note the tumor and nucleus need to be created after the collagen,
        # to prevent the cell cluster and collagen cluster to coincide
        
        # Create the tumor
        tumor = self.new_cell(self.typeTumor)
        tumor.targetVolume = self.tumorTargetVolume
        tumor.lambdaVolume = self.tumorLambdaVolume
        self.cell_field[50, self.dim.y//2, 0] = tumor
        self.myTumor = tumor
        
        # Create the nucleus
        nucleus = self.new_cell(self.typeNucleus)
        nucleus.targetVolume = self.nucleusTargetVolume
        nucleus.lambdaVolume = self.nucleusLambdaVolume
        self.cell_field[40, self.dim.y//2, 0] = nucleus
        self.myNucleus = nucleus
        
        # Create the membrane
        membrane = self.new_cell(self.typeMembrane)
        membrane.targetVolume = self.membraneTargetVolume
        membrane.lambdaVolume = self.membraneLambdaVolume
        self.cell_field[60, self.dim.y//2, 0] = membrane
        self.myTumor = membrane
        
        # An example of how a graph would be added
        #self.plot_win = self.add_new_plot_window(
        #title='Relative distance of the Center of Mass of the Tumor and Nucleus',
        #x_axis_title='MonteCarlo Step*10 (MCS)',
        #y_axis_title='Relative distance',
        #x_scale_type='linear',
        #y_scale_type='linear',
        #grid=True  )
        #self.plot_win.add_plot("Relative distance", style='Dots', color='red', size=5)
      
    def step(self, mcs):
        '''
        # Change the strength of the external potential depending on the amount of tumor pixels in contact with collagen
        contact_area = 0 #total contact area between tumor and collagen
        
        for neighbor, common_surface_area in self.get_cell_neighbor_data_list(self.myTumor):
            if neighbor and neighbor.type == self.typeCollagen:
                contact_area += int(common_surface_area)
        
        # Change the external potential on the cell depending on the contact area with collagen
        # Simplest model: linear dependence
        scale = 1
        threshold = 120
        self.myTumor.lambdaVecX = min(-(scale * contact_area - threshold), 0) #(negative lambda = movement towards positive x)
        print("contact area = ", contact_area, "lambda = ", self.myTumor.lambdaVecX)
        '''
        
        # Occasionally generate chemical "pulses" that make the cell form protrusions
        if mcs > 50: # Wait for some initial delay to give the cell time to form
            pulse_delay = 150       # Number of MC steps between each protrusion-generating pulse
            pulse_strength = 25000  # Strength of the chemical pulse
            pulse_distance = 32     # Maximum number of pixels away from the cell's COM that the pulse should be generated
            #min_x_pulse_distance = 5 #Minimum number of pixels that the pulse should be to the right of the furthest pixel
            max_angle = 1         # Max angle of the offset vector relative to the x-axis (lower this value to get more protrusions to the right rather than up/down)

            if mcs % pulse_delay == 0:
                COM = np.array([self.myTumor.xCOM, self.myTumor.yCOM])           # Center of mass of the cell
                
                #Get the pixel of the cell that is the furthest to the right
                pixel_list = list(self.get_cell_pixel_list(self.myTumor)) # This list is sorted by x-coordinate
                # ^ This could also use get_cell_boundary_pixel_list instead; that might take less memory, but slightly more processing time
                
                
                # Fastest method: just pick the last pixel (with biggest x-coord)
                # Problem: this is also the pixel with greatest y, so pulses are biased to spawn further up
                #furthest_pixel = pixel_list[-1].pixel
                #furthest_pos = [furthest_pixel.x, furthest_pixel.y]
                
                # Less biased method: of all pixels with highest x, take the average of the highest and lowest y
                i = 1
                pixel_data = pixel_list[-1] # of all pixels with highest x, this is the one with highest y
                furthest_x = pixel_data.pixel.x
                y1 = pixel_data.pixel.y
                # Keep going down the list until we encounter a pixel that no longer has highest x
                while pixel_data.pixel.x == furthest_x:
                    i += 1
                    pixel_data = pixel_list[-i]
                pixel_data = pixel_list[-i+1] # of all pixels with highest x, this is the one with lowest y
                y2 = pixel_data.pixel.y
                furthest_y = int((y1+y2)/2) # take the average of highest and lowest y
                furthest_pos = [furthest_x, furthest_y]
                
                # OLD VERSION (LESS EFFICIENT)
                #boundary_list = self.get_cell_boundary_pixel_list(self.myTumor)  # List of all boundary pixels of the cell
                #collagen_list = self.cell_list_by_type(self.typeCollagen)        # List of all collagen cells
                
                #Get the pixel of the cell that is the furthest to the right
                #x_max = 0
                #for pixel_data in boundary_list:
                    #Find the furthest pixel
                    #if pixel_data.pixel.x > x_max:
                        #furthest_pixel = pixel_data.pixel
                    #Briefly freeze a cell when it comes into contact with collagen (not functional)
                    #neighbors = get_pixel_neighbors_based_on_neighbor_order(pixel_data.pixel, 1)
                    #for neighborPt in neighbors:
                        #neighbor = self.cell_field[neighborPt.pt.x, neighborPt.pt.y, 0]
                        #if neighbor.type == self.typeCollagen:
                            #pixel_data.
                #furthest_pos = [furthest_pixel.x, furthest_pixel.y]
                #NB I tried to do this in a fancier way like below: 
                    #CC3D keeps the boundary list sorted by x value of each pixel (low to high),
                    #so the right-most pixel is always the last in the list.
                    #furthest_pixel = boundary[-1]
                #The problem is that the boundary object is not iterable, and I couldn't find a way to make it work...
                
                #CLASSIC VERSION: spawns pulses at a random angle, not just on collagen.
                pulse_distance = np.linalg.norm(furthest_pos-COM)/2 + 15
                rand_angle = random.uniform(-max_angle, max_angle)
                offset = pulse_distance * np.array([np.cos(rand_angle), np.sin(rand_angle)])
                pulse_pos = np.floor(COM + (furthest_pos - COM)/2 + offset)
                self.field.ChemField[pulse_pos[0], pulse_pos[1], 0] = pulse_strength # Generate a pulse at furthest pixel position + offset in the direction of the external potential
                
                #Spawn the pulse at a collagen pixel that is within a certain distance of the furthest pixel of the cell
                
                '''
                #VERSION 0.5 (shoot a ray from the mid-point of the furthest pixel and the COM, and spawn a pulse if it hits collagen within a certain distance)
                min_x_distance = np.linalg.norm(furthest_pos - COM)/2 + 5   #Minimum distance a ray needs to be
                test_pos = np.array(COM + (furthest_pos - COM)/2)
                test_cell = self.cell_field[np.floor(test_pos[0]), np.floor(test_pos[1]), 0]
                while ((not test_cell) or test_cell.type != self.typeCollagen): 
                    # Until we encounter a collagen cell within suitable distance: shoot a ray at a random angle and walk through the ray pixel-by-pixel
                    rand_angle = random.uniform(-max_angle, max_angle)
                    tan = np.tan(rand_angle)
                    distance = 0
                    test_pos = np.array(COM + (furthest_pos - COM)/2)
                    test_cell = self.cell_field[np.floor(test_pos[0]), np.floor(test_pos[1]), 0]
                    while distance < min_x_distance or (distance < pulse_distance and ((not test_cell) or test_cell.type != self.typeCollagen)):
                        distance += 1
                        #To ensure the program checks all pixels along the ray (either the x step or y step does not exceed 1)
                        if tan <= 1.0:
                            test_pos = [test_pos[0] + 1, test_pos[1] + tan]
                        else:
                            test_pos = [test_pos[0] + 1/tan, test_pos[1] + 1]
                        #Start checking if we've hit collagen cells once we're past the minimum distance
                        if distance >= min_x_distance:
                            test_cell = self.cell_field[np.floor(test_pos[0]), np.floor(test_pos[1]), 0]
                    #Gradually increase the max allowed distance so we don't get stuck finding no suitable position
                    pulse_distance += 1
                self.field.ChemField[np.floor(test_pos[0]), np.floor(test_pos[1]), 0] = pulse_strength #Spawn a pulse at the found collagen pixel
                '''

                #VERSION 0.4 (check all pixels within a certain neighbor order of furthest_pixel, select the collagen pixels with greater x position, and pick a random one of these to generate the pulse on
                #this is very slow, the program basically crashes every time now
                #neighbor_order_step = 5
                #min_x_distance = 5
                #neighbor_order = pulse_distance
                #good_collagen = []
                #while good_collagen == []:
                    #neighbors = self.get_pixel_neighbors_based_on_neighbor_order(furthest_pixel, neighbor_order)
                    #for neighborPt in neighbors:
                        #print('hey')
                        #if neighborPt.pt.x-furthest_pos[0] > min_x_distance:
                            #neighbor = self.cell_field[neighborPt.pt.x, neighborPt.pt.y, 0]
                            #print('this one is OK')
                            #if neighbor and neighbor.type == self.typeCollagen:
                                #good_collagen.append(neighbor)
                                #print('collagen found')
                    #neighbor_order += neighbor_order_step
                #pulse_pos = random.choice(good_collagen)
                #self.field.ChemField[pulse_pos.pixel.x, pulse_pos.pixel.y, 0] = pulse_strength # Generate a pulse at furthest pixel position + offset in the direction of the external potential
                
                #VERSION 0.3 (pick the first good pixel we come across):
                #faster than version 0.2, but always ends up pixels on the same line (in this case the top of the tunnel)
                #for collagen_cell in collagen_list:
                    #collagen_boundary = self.get_cell_boundary_pixel_list(collagen_cell)   #Get all boundary pixels of this collagen cell
                    #for collagen_pixel in collagen_boundary:
                        #if collagen_pixel.pixel.x - furthest_pixel.x > min_x_pulse_distance and np.linalg.norm([collagen_pixel.pixel.x - furthest_pixel.x, collagen_pixel.pixel.y - furthest_pixel.y]) < pulse_distance:
                            #self.field.ChemField[collagen_pixel.pixel.x, collagen_pixel.pixel.y, 0] = pulse_strength # Generate a pulse at the collagen pixel
                            #return
                
                #VERSION 0.2 (store a list of all collagen pixels and pick a good one): 
                #this works, but costs too much processing power (the program noticably lags every 150th step)
                #good_pixels = []
                #for collagen_cell in collagen_list:
                    #collagen_boundary = self.get_cell_boundary_pixel_list(collagen_cell)   #Get all boundary pixels of this collagen cell
                    #for collagen_pixel in collagen_boundary:
                        #print('x = ' + str(collagen_pixel.pixel.x))
                        #if np.linalg.norm([collagen_pixel.pixel.x - furthest_pixel.x, collagen_pixel.pixel.y - furthest_pixel.y]) < pulse_distance:
                            #good_pixels.append(collagen_pixel)
                #pixel = random.choice(good_pixels)   #Pick a random good collagen pixel
                #self.field.ChemField[pixel.pixel.x, pixel.pixel.y, 0] = pulse_strength # Generate a pulse at the collagen pixel
                
                #VERSION 0.1: generate pulses at a random-angled offset relative to the cell
                #rand_angle = random.uniform(-max_angle, max_angle)
                #offset = (np.linalg.norm(furthest_pos - COM) + pulse_distance) * np.array([np.cos(rand_angle), np.sin(rand_angle)])
                #pulse_pos = np.floor(COM + offset)
                #self.field.ChemField[pulse_pos[0], pulse_pos[1], 0] = pulse_strength # Generate a pulse at COM position + offset in the direction of the external potential

    # Compute the total target volume of a given cell type
    def totalTargetVolumeByCell(self, type):
        totalVolume = 0
        for cell in self.cell_list_by_type(type):
            totalVolume += cell.targetVolume
        return totalVolume    

    # Compute the total target volume of a given cell type within a cluster
    def totalTargetVolumeByCellGivenClusters(self, type, clusterSet):
        totalVolumeArray = [0] * (len(clusterSet))
        for cell in self.cell_list_by_type(type):
            totalVolumeArray[cell.clusterId] += cell.targetVolume
        return totalVolumeArray

    # Swap collagen clusters    #*** Wat is hier het nut van?
    def swapCollagenClusters(self, oldCluster, newCluster):
        for collagen in self.cell_list_by_type(self.typeCollagen):
            if collagen.clusterId == oldCluster:
                self.reassign_cluster_id(collagen, newCluster)
            elif collagen.clusterId == newCluster:
                self.reassign_cluster_id(collagen, oldCluster)

    def on_stop(self):
        # Debug statement
        self.printLog()
        self.printLog('Cell list when stopped')
        self.printLog('type, cluster id, target volume')
        for cell in self.cell_list:
            self.printLog(self.typeToName(cell.type), cell.clusterId, cell.targetVolume)
        self.printLog()
        
        self.printLog('Steppable is stopped')
        self.myFile.close()
        return

    def finish(self):
        self.printLog('Steppable is finished')
        self.myFile.close()
        return
