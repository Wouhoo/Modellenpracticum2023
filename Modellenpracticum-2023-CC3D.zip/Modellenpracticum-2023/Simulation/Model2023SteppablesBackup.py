import numpy as np
import random
import math
from datetime import datetime
from cc3d.core.PySteppables import *

import os
try:
    import yaml
except ModuleNotFoundError:
    raise ModuleNotFoundError(f"Could not find the yaml module. Make sure to install it with 'pip install pyyaml'")

config = yaml.safe_load(open("../config.yml"))
config_model = config["Model Parameters"]
config_volume = config["Volume Parameters"]
config_collagen = config["Collagen Generation"]

### Modifiable parameters will be marked with 3 #'s like this ###


class Model2023Steppable(SteppableBasePy):
    def __init__(self,frequency=1):
        SteppableBasePy.__init__(self,frequency)
        # References to cell types
        self.typeCollagen = 1
        self.typeTumor = 2
        self.typeNucleus = 3
        self.typeMembrane = 4
        
        # Initialize cell references
        self.myTumor = None
        self.myNucleus = None
        self.myMembrane = None
        
        ### Volume atributes of the tumor, nucleus and membrane ###
        self.tumorTargetVolume = 3000
        self.tumorLambdaVolume = 10
        self.nucleusTargetVolume = 350 # Supposed to be about 10 procent of total target volume
        self.nucleusLambdaVolume = 20
        self.membraneTargetVolume = 700
        self.membraneLambdaVolume = 5
        
        # Neighbor order of 'get_pixel_neighbors_based_on_neighbor_order'
        self.BoundaryPixelNeighborOrder = 1
        
        # Clustering counting variable
        self.collagenClusterCounter = 0
        
        ### Name & location of the log file (you may have to edit the filePath in order for the program to work) ###
        fileName = 'MyLog' 
        filePath = '/Users/Wouter/Documents/Modellenpracticum/Modellenpracticum-2023/Simulation'
        
        # Open log file
        fileLoc = '/'.join([filePath, fileName + '.piff'])
        self.myFile = open(fileLoc, 'w')
        currentTime = datetime.now()
        printTime = currentTime.strftime("%H:%M:%S")
        self.printLog('Steppable initialized on', printTime)

    # Print to log file
    def printLog(self, *args):
        for arg in args:
            self.myFile.write(str(arg) + ' ')
        self.myFile.write('\n')

    # Print array to log file
    def printLogArr(self, arr):
        for elm in arr:
            self.printLog(elm)
    
    # Translates type id to type name
    def typeToName(self, type):
        return ['Medium', 'Collagen', 'Tumor', 'Nucleus', 'Membrane'][type]
            
    # Create a track with an adjustable narrowing    
    def CollagenCreator(self, upper_x,upper_y,lower_x,lower_y):
        ### Fixed dimensions of the start of the track ###
        fixed_width = 100
        fixed_height = 50
        
        # Create all upper track elements
        collagen_upper_fixed = self.new_cell(self.typeCollagen) # Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2+fixed_height//2, 0] = collagen_upper_fixed
        
        collagen_upper_x = self.new_cell(self.typeCollagen) # Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-upper_x:self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_x
       
        collagen_upper_x_left = self.new_cell(self.typeCollagen) # Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-upper_x, self.dim.y//2+fixed_height//2, 0] = collagen_upper_x_left
        
        # Distinct between a narrowing and a widening
        if upper_y > 0:
            collagen_upper_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2+fixed_height//2:self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_y
            
            collagen_upper_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-upper_x, self.dim.y//2+fixed_height//2:self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_y_left
        else:
            collagen_upper_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2, 0] = collagen_upper_y
            
            collagen_upper_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-upper_x, self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2, 0] = collagen_upper_y_left      
        
        # Assign the same cluster id to all upper track elements
        self.reassign_cluster_id(collagen_upper_fixed, 0)
        self.reassign_cluster_id(collagen_upper_x, 0)
        self.reassign_cluster_id(collagen_upper_x_left, 0)
        self.reassign_cluster_id(collagen_upper_y, 0)
        self.reassign_cluster_id(collagen_upper_y_left, 0)
        
        # Create all lower track elements
        collagen_lower_fixed = self.new_cell(self.typeCollagen) # Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2-fixed_height//2, 0] = collagen_lower_fixed
        
        collagen_lower_x = self.new_cell(self.typeCollagen) # Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-lower_x:self.dim.x-fixed_width, self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_x
        
        collagen_lower_x_left = self.new_cell(self.typeCollagen) # Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-lower_x, self.dim.y//2-fixed_height//2, 0] = collagen_lower_x_left
        
        # Distinct between a narrowing and a widening
        if lower_y > 0:
            collagen_lower_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2-fixed_height//2-lower_y:self.dim.y//2-fixed_height//2, 0] = collagen_lower_y
            
            collagen_lower_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-lower_x, self.dim.y//2-fixed_height//2-lower_y:self.dim.y//2-fixed_height//2, 0] = collagen_lower_y_left
        else:
            collagen_lower_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2-fixed_height//2:self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_y
            
            collagen_lower_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-lower_x, self.dim.y//2-fixed_height//2:self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_y_left      
        
        # Assign the same cluster id to all lower track elements
        self.reassign_cluster_id(collagen_lower_fixed, 1)
        self.reassign_cluster_id(collagen_lower_x, 1)
        self.reassign_cluster_id(collagen_lower_x_left, 1)
        self.reassign_cluster_id(collagen_lower_y, 1)
        self.reassign_cluster_id(collagen_lower_y_left, 1)
        
    # Create a track that is diagonal at the end of the narrowing    
    def DiagonalCollagenCreator(self):
        ### Set all dimensions ###
        fixed_width = 100
        fixed_height = 50
        upper_x = 100
        upper_y = -10
        lower_x = 100
        lower_y = -10
        
        # Create all upper track elements
        collagen_upper_fixed = self.new_cell(self.typeCollagen) # Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2+fixed_height//2, 0] = collagen_upper_fixed
        
        collagen_upper_x = self.new_cell(self.typeCollagen) # Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-upper_x:self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_x
       
        collagen_upper_x_left = self.new_cell(self.typeCollagen) # Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-upper_x-10, self.dim.y//2+fixed_height//2, 0] = collagen_upper_x_left
        
        
        collagen_upper_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
        self.cell_field[self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2, 0] = collagen_upper_y
        
        # Create all steps at the end of the narrowing
        collagen_upper_step1 = self.new_cell(self.typeCollagen) 
        self.cell_field[self.dim.x-fixed_width-upper_x-2:self.dim.x-fixed_width-upper_x,self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2+upper_y+2,0] = collagen_upper_step1
        
        collagen_upper_step2 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-4:self.dim.x-fixed_width-upper_x-2,self.dim.y//2+fixed_height//2+upper_y+2:self.dim.y//2+fixed_height//2+upper_y+4,0] = collagen_upper_step2
        
        collagen_upper_step3 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-6:self.dim.x-fixed_width-upper_x-4,self.dim.y//2+fixed_height//2+upper_y+4:self.dim.y//2+fixed_height//2+upper_y+6,0] = collagen_upper_step3
        
        collagen_upper_step4 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-8:self.dim.x-fixed_width-upper_x-6,self.dim.y//2+fixed_height//2+upper_y+6:self.dim.y//2+fixed_height//2+upper_y+8,0] = collagen_upper_step4
        
        collagen_upper_step5 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-10:self.dim.x-fixed_width-upper_x-6,self.dim.y//2+fixed_height//2+upper_y+8:self.dim.y//2+fixed_height//2+upper_y+10,0] = collagen_upper_step5
        
        # Assign the same cluster id to all upper track elements
        self.reassign_cluster_id(collagen_upper_fixed, 0)
        self.reassign_cluster_id(collagen_upper_x, 0)
        self.reassign_cluster_id(collagen_upper_x_left, 0)
        self.reassign_cluster_id(collagen_upper_y, 0)
        self.reassign_cluster_id(collagen_upper_step1, 0)
        self.reassign_cluster_id(collagen_upper_step2, 0)
        self.reassign_cluster_id(collagen_upper_step3, 0)
        self.reassign_cluster_id(collagen_upper_step4, 0)
        self.reassign_cluster_id(collagen_upper_step5, 0)
        
        # Create all lower track elements
        collagen_lower_fixed = self.new_cell(self.typeCollagen) # Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2-fixed_height//2, 0] = collagen_lower_fixed
        
        collagen_lower_x = self.new_cell(self.typeCollagen) # Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-lower_x:self.dim.x-fixed_width, self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_x
        
        collagen_lower_x_left = self.new_cell(self.typeCollagen) # Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-lower_x-10, self.dim.y//2-fixed_height//2, 0] = collagen_lower_x_left
        
        collagen_lower_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
        self.cell_field[self.dim.x-fixed_width, self.dim.y//2-fixed_height//2:self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_y
        
        # Create all steps at the end of the narrowing 
        collagen_lower_step1 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-2:self.dim.x-fixed_width-lower_x,self.dim.y//2-fixed_height//2-lower_y-2:self.dim.y//2-fixed_height//2-lower_y,0] = collagen_lower_step1
        
        collagen_lower_step2 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-4:self.dim.x-fixed_width-lower_x-2,self.dim.y//2-fixed_height//2-lower_y-4:self.dim.y//2-fixed_height//2-lower_y-2,0] = collagen_lower_step2
        
        collagen_lower_step3 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-6:self.dim.x-fixed_width-lower_x-4,self.dim.y//2-fixed_height//2-lower_y-6:self.dim.y//2-fixed_height//2-lower_y-4,0] = collagen_lower_step3
        
        collagen_lower_step4 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-8:self.dim.x-fixed_width-lower_x-6,self.dim.y//2-fixed_height//2-lower_y-8:self.dim.y//2-fixed_height//2-lower_y-6,0] = collagen_lower_step4
        
        collagen_lower_step5 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-10:self.dim.x-fixed_width-lower_x-6,self.dim.y//2-fixed_height//2-lower_y-10:self.dim.y//2-fixed_height//2-lower_y-8,0] = collagen_lower_step5
         
        # Assign the same cluster id to all lower track elements
        self.reassign_cluster_id(collagen_lower_fixed, 1)
        self.reassign_cluster_id(collagen_lower_x, 1)
        self.reassign_cluster_id(collagen_lower_x_left, 1)
        self.reassign_cluster_id(collagen_lower_y, 1)
        self.reassign_cluster_id(collagen_lower_step1, 1)
        self.reassign_cluster_id(collagen_lower_step2, 1)
        self.reassign_cluster_id(collagen_lower_step3, 1)
        self.reassign_cluster_id(collagen_lower_step4, 1)
        self.reassign_cluster_id(collagen_lower_step5, 1)
        
    # Auxiliary function: Draws a collagen fiber between (x1,y1) and (x2,y2)
    def drawDDA(self,x1,y1,z1,x2,y2,z2):
        pixList=[]
        x,y = x1,y1
        z = z1
        length = max(abs(x2-x1),abs(y2-y1),abs(z2-z1))
        dx = (x2-x1)/float(length)
        dy = (y2-y1)/float(length)
        dz = (z2-z1)/float(length)
        pixList.append((int(x),int(y),int(z)))
        for i in range(abs(length)):
            x += dx
            y += dy
            z += dz
            pixList.append((int(x),int(y),int(z)))
        return pixList
        
    # Generates a random network of collagen fibers
    def CollagenNetwork(self):
        lx = self.dim.x #Window x width
        ly = self.dim.y #Window y width
        lz = self.dim.z #Window z width
        ### Parameters for generating the fibers ###
        v = 35  #Number of fibers 
        fl = 35 #Length of the fibers in pixels
        maxThetaAngle = 0.5*math.pi #Maximum angle of the fibers relative to the x axis; lower this to orient the network more
        maxPhiAngle = 0.5*math.pi #Max angle of the fibers in the z direction
        tunnelWidth = 0 #To create a sort of tunnel in the network if desired (set to 0 to not create the tunnel)

        ### Uncomment to test the same network multiple times if desired ###
        #random.seed(12) 
        
        #For every number in the number of fibers, now create a fiber        
        for i in range(v):
            cell = self.new_cell(self.COLLAGEN)  #Create a new cell for this fiber
            pixList = []
            m = int(lx*random.random())
            n = int(ly*random.random())
            p = int(lz*random.random())
            # make it so the area where the cell spawns remains mostly clear of fibers (so the cell can be created properly)
            while 20 < m and m < 60:    
                m = int(lx*random.random())
            # create a tunnel
            while ly//2 - tunnelWidth < n and n < ly//2 + tunnelWidth:
                n = int(ly*random.random())
            theta = math.pi*(2*random.random() - 1) #theta(orientation x and y)and phi(orientation z)are in [-pi,pi]
            phi = math.pi*(2*random.random() - 1)
            # make it so the fibers will orient to the right
            while np.abs(theta) > maxThetaAngle: # theta should be close to zero in an oriented network
                theta = math.pi*(2*random.random() - 1)
            while np.abs(phi) < 0.5*math.pi - maxPhiAngle: #phi should be large in an oriented network
                phi = math.pi*(2*random.random() - 1)
            x = int(m+fl*math.cos(theta)*math.sin(phi))
            y = int(n+fl*math.sin(theta)*math.sin(phi))
            z = int(p+fl*math.cos(phi))
            print(i, x,m, y,n, z,p)
            pixList = self.drawDDA(x,y,z, m,n,p)
            if len(pixList) > 0:
                for (px,py,pz) in pixList: 
                    px = min(max(px,0),lx-1)  #0<=px<=lx-1
                    py = min(max(py,0),ly-1)  #0<=py<=ly-1
                    pz = min(max(pz,0),lz-1)  #0<=pz<=lz-1
                    self.cell_field[px:px+1, py:py+1, pz:pz+1] = cell #Add this pixel to the cell
            cell.targetVolume = cell.volume  
            cell.lambdaVolume = 10000        
    
    # Create various tracks with different dimensions
    def CollagenTrack(self, tracknumber):
        # y values may not exceed 55
        # x values may not exceed 300
        # Input are the dimensions of the narrowing= upper_x,upper_y,lower_x,lower_y 
        
        # Straight tube
        if tracknumber == 1: 
            self.CollagenCreator(0,0,0,0)
        # Upper indent
        elif tracknumber == 2:
            self.CollagenCreator(100,-30,0,0)
        # Lower indent
        elif tracknumber == 3:
            self.CollagenCreator(0,0,100,-12)
        # Upper and lower indent
        elif tracknumber == 4:
            self.CollagenCreator(150,-10,150,-10)
        # Upper and lower indent shifted
        elif tracknumber == 5:
            self.CollagenCreator(100,-12,150,-12)
        # Sharp upper and lower indent
        elif tracknumber == 6:
            self.CollagenCreator(10,-15,10,-15)
        # Broadening
        elif tracknumber == 7:
            self.CollagenCreator(300,5,300,5)
        # Diagonal version of track 4
        elif tracknumber == 8:
            self.DiagonalCollagenCreator()
        # Random network
        elif tracknumber == 9:
            self.CollagenNetwork()
    
    # Set up the simulation (called at the start)
    def start(self):   
        #Create the chemical field
        #self.ChemFieldCreator(10000, 4)
        
        ### Create a collagen track of chosen type (see CollagenTrack function) ###
        self.CollagenTrack(1)
            
        # Note the cell parts need to be created after the collagen,
        # to prevent the cell cluster and collagen cluster to coincide
        
        # Create the tumor
        tumor = self.new_cell(self.typeTumor)
        tumor.targetVolume = self.tumorTargetVolume
        tumor.lambdaVolume = self.tumorLambdaVolume
        self.cell_field[50, self.dim.y//2, self.dim.z//2] = tumor
        self.myTumor = tumor
        
        # Create the nucleus
        nucleus = self.new_cell(self.typeNucleus)
        nucleus.targetVolume = self.nucleusTargetVolume
        nucleus.lambdaVolume = self.nucleusLambdaVolume
        self.cell_field[40, self.dim.y//2, self.dim.z//2] = nucleus
        self.myNucleus = nucleus
        
        # Create the membrane
        membrane = self.new_cell(self.typeMembrane)
        membrane.targetVolume = self.membraneTargetVolume
        membrane.lambdaVolume = self.membraneLambdaVolume
        self.cell_field[60, self.dim.y//2, self.dim.z//2] = membrane
        self.myMembrane = membrane
        
        ### An example of how a graph would be added (initialization) ###
        self.plot_win = self.add_new_plot_window(
            title='Cell x position',
            x_axis_title='MonteCarlo Step*20 (MCS)',
            y_axis_title='x position (pixels)',
            x_scale_type='linear',
            y_scale_type='linear',
            grid=True  )
        self.plot_win.add_plot("Cell x position", style='Dots', color='red', size=5)
    
    # This function is called every Monte Carlo step  
    def step(self, mcs):
        ### Parameters for what model to use (parameters for the individual models can be found further below) ###
        chemPulses = True # Controls cell movement; set to False to use the ExternalPotential plugin
        #or True to use chemical pulse model.
        contactDependant = False # If using the ExternalPotential plugin: set to False for default external potential 
        #or True to make the potential dependant on membrane-collagen contact area
        rayTracing = False # If using the chemical pulse model: set to False to generate pulses randomly
        #or True to use ray-tracing to generate pulses only on collagen (this might slow down the simulation quite a bit)
        
        if mcs > 50: # Wait for some initial delay to give the cell time to form
            if not chemPulses:
                # Exert a constant force on the cell using the ExternalPotential plugin
                if not contactDependant:
                    ### Lambda to use in case of default external potential (negative lambda = movement towards positive x) ###
                    self.myMembrane.lambdaVecX = -15.0
                else:
                    # Change the strength of the external potential depending on the amount of membrane pixels in contact with collagen
                    contact_area = 0 #total contact area between membrane and collagen
                    for neighbor, common_surface_area in self.get_cell_neighbor_data_list(self.myMembrane):
                        if neighbor and neighbor.type == self.typeCollagen:
                            contact_area += int(common_surface_area)
                    ### Simplest model: linear dependence (change if desired) ###
                    scale = 1
                    threshold = 60
                    self.myMembrane.lambdaVecX = min(-(scale * contact_area - threshold), 0)
                    print("contact area = ", contact_area, "lambda = ", self.myMembrane.lambdaVecX) #for debugging
            else:
            # Occasionally generate chemical "pulses" that make the cell form protrusions
                ### Pulse parameters ###
                pulse_delay = 150          # Number of MC steps between each protrusion-generating pulse
                pulse_strength = 25000     # Strength of the chemical pulse
                max_angle = 1              # Max angle of the offset vector relative to the x-axis (lower this value to get more protrusions to the right rather than up/down)
                random_pulse_distance = 15 # In case of random pulse position: Distance from the average of the cell's COM and furthest pixel that the pulse should be generated
                min_x_distance = 5         # In case of ray-tracing: Minimum number of pixels that the pulse should be to the right of the furthest pixel-COM-average
                max_x_distance = 32        # In case of ray-tracing: Maximum number of pixels away from the cell's furthest pixel-COM-average that the pulse should be generated
                self.myMembrane.lambdaVecX = -2.5 #A small external potential to prevent the cell from snapping back too quickly if no pulse is nearby

                # Find the cell's COM and furthest pixel
                if mcs % pulse_delay == 0:
                    COM = np.array([self.myTumor.xCOM, self.myTumor.yCOM]) # Center of mass of the cell
                    #Get the pixel of the cell that is the furthest to the right
                    pixel_list = list(self.get_cell_pixel_list(self.myTumor)) # This list is sorted by x-coordinate
                    # ^ This could also use get_cell_boundary_pixel_list instead
                
                    # Of all pixels with highest x, take the average of the highest and lowest y
                    # Less biased method: of all pixels with highest x, take the average of the highest and lowest y and z
                    i = 1
                    pixel_data = pixel_list[-1] # of all pixels with highest x, this is the one with highest y and z
                    furthest_x = pixel_data.pixel.x
                    y1 = pixel_data.pixel.y
                    # Keep going down the list until we encounter a pixel that no longer has highest x
                    while pixel_data.pixel.x == furthest_x:
                        i += 1
                        pixel_data = pixel_list[-i]
                    pixel_data = pixel_list[-i+1] # of all pixels with highest x, this is the one with lowest y
                    y2 = pixel_data.pixel.y
                    furthest_y = int((y1+y2)/2) # take the average of highest and lowest y
                    furthest_pos = [furthest_x, furthest_y]
                            
                    if not rayTracing:
                        #Spawns pulses at a random angle, not just on collagen.
                        pulse_distance = np.linalg.norm(furthest_pos-COM)/2 + random_pulse_distance
                        rand_angle = random.uniform(-max_angle, max_angle)
                        offset = pulse_distance * np.array([np.cos(rand_angle), np.sin(rand_angle)])
                        pulse_pos = np.floor(COM + (furthest_pos - COM)/2 + offset)
                        # Generate a pulse at average of COM and furthest pixel position + offset in the direction of the external potential
                        self.field.ChemField[pulse_pos[0], pulse_pos[1], 0] = pulse_strength 
                    else:
                        #Spawn the pulse at a collagen pixel that is within a certain distance of the furthest pixel of the cell
                        test_pos = np.array(COM + (furthest_pos - COM)/2)
                        test_cell = self.cell_field[np.floor(test_pos[0]), np.floor(test_pos[1]), 0]
                        while ((not test_cell) or test_cell.type != self.typeCollagen): 
                            # Until we encounter a collagen cell within suitable distance: shoot a ray at a random angle and walk through the ray pixel-by-pixel
                            rand_angle = random.uniform(-max_angle, max_angle)
                            tan = np.tan(rand_angle)
                            distance = 0
                            test_pos = np.array(COM + (furthest_pos - COM)/2)
                            test_cell = self.cell_field[np.floor(test_pos[0]), np.floor(test_pos[1]),0]
                            while distance < min_x_distance or (distance < max_x_distance and ((not test_cell) or test_cell.type != self.typeCollagen)):
                                distance += 1
                                #To ensure the program checks all pixels along the ray (either the x step or y step does not exceed 1)
                                if tan <= 1.0:
                                    test_pos = [test_pos[0] + 1, test_pos[1] + tan]
                                else:
                                    test_pos = [test_pos[0] + 1/tan, test_pos[1] + 1]
                                #Start checking if we've hit collagen cells once we're past the minimum distance
                                if distance >= min_x_distance:
                                    test_cell = self.cell_field[np.floor(test_pos[0]), np.floor(test_pos[1]),0]
                            #Gradually increase the max allowed distance so we don't get stuck finding no suitable position
                            max_x_distance += 1
                        self.field.ChemField[np.floor(test_pos[0]), np.floor(test_pos[1]), 0] = pulse_strength #Spawn a pulse at the found collagen pixel
        
        ### An example of how a graph would be created (adding data points) ###
        if self.myTumor:
            if mcs % 20 == 0:
                self.plot_win.add_data_point('Cell x position', mcs/20, self.myTumor.xCOM)
    
    # Compute the total target volume of a given cell type
    def totalTargetVolumeByCell(self, type):
        totalVolume = 0
        for cell in self.cell_list_by_type(type):
            totalVolume += cell.targetVolume
        return totalVolume    

    # Compute the total target volume of a given cell type within a cluster
    def totalTargetVolumeByCellGivenClusters(self, type, clusterSet):
        totalVolumeArray = [0] * (len(clusterSet))
        for cell in self.cell_list_by_type(type):
            totalVolumeArray[cell.clusterId] += cell.targetVolume
        return totalVolumeArray

    def on_stop(self):
        # Debug statement
        self.printLog()
        self.printLog('Cell list when stopped')
        self.printLog('type, cluster id, target volume')
        for cell in self.cell_list:
            self.printLog(self.typeToName(cell.type), cell.clusterId, cell.targetVolume)
        self.printLog()
        
        self.printLog('Steppable is stopped')
        self.myFile.close()
        return

    def finish(self):
        self.printLog('Steppable is finished')
        self.myFile.close()
        return
