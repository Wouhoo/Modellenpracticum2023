import numpy as np
import random
import math
from datetime import datetime
from cc3d.core.PySteppables import *

class Model2023Steppable(SteppableBasePy):
    def __init__(self, frequency=1):
        SteppableBasePy.__init__(self, frequency)
        
        # References to cell types
        self.typeCollagen = 1
        self.typeTumor = 2
        
        # Initialize cell references
        self.myTumor = None
        
        # Volume atributes of the tumor, nucleus and membrane
        self.tumorTargetVolume = 3000
        self.tumorLambdaVolume = 10
        
        #Neighbor order of 'get_pixel_neighbors_based_on_neighbor_order'
        self.BoundaryPixelNeighborOrder = 1
        
        #Name and location of log file
        fileName = 'MyLog'
        filePath = '/Users/Wouter/Documents/Modellenpracticum/Modellenpracticum-2023-3d/Simulation' #adjustable
        
        #Open log file
        fileLoc = '/'.join([filePath, fileName + '.piff'])
        self.myFile = open(fileLoc, 'w')
        currentTime = datetime.now()
        printTime = currentTime.strftime("%H:%M:%S")
        self.printLog('Steppable initialized on', printTime)

    #Print to log file
    def printLog(self,*args):
        for arg in args:
            self.myFile.write(str(arg) + ' ')
        self.myFile.write('\n')
            
    #Print array to log file
    def printLogArr(self, arr):
        for elm in arr:
            self.printLog(elm)

    #Translates type id to type name
    def typeToName(self, type):
        return ['Medium', 'Collagen', 'Tumor'][type]
    
    #Create a chemical field with a linear gradient
    #by creating a single line at the right border and letting is diffuse
    def ChemFieldCreaterV2(self, field_strength):
        for y in range(self.dim.y):
            self.field.ChemField[self.dim.x-1,y,0] = field_strength #moet nog iets met z!!!!
            
    #Create a track with an adjustable narrowing #nog niets met z gedaan.
    def CollagenCreator(self, upper_x, upper_y, lower_x, lower_y):
        #Fixed Dimensions of the start of the track
        fixed_width = 100
        fixed_height = 50
                
        #Create all upper track elements
        collagen_upper_fixed = self.new_cell(self.typeCollagen) #Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2+fixed_height//2, 0] = collagen_upper_fixed
        collagen_upper_x = self.new_cell(self.typeCollagen) #Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-upper_x:self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_x
        collagen_upper_x_left = self.new_cell(self.typeCollagen) # Horizontal element of narrowing
        self.cell_field[0:self.dim.x-fixed_width-upper_x, self.dim.y//2+fixed_height//2, 0] = collagen_upper_x_left
        #Distinct between a narrowing and a widenimg
        if upper_y > 0:
            collage_upper_y = self.new_cell(self.typeCollagen) #Vertical element at the end of narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2+fixed_height//2:self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_y
            collagen_upper_y = self.new_cell(self.typeCollagen) #Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width-upper_x, self.dim.y//2+fixed_height//2:self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_y_left
        else:
            collagen_upper_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2, 0] = collagen_upper_y
            collagen_upper_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-upper_x, self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2, 0] = collagen_upper_y_left
        #Assign the same cluster id to all upper track elements	
        self.reassign_cluster_id(collagen_upper_fixed, 0)
        self.reassign_cluster_id(collagen_upper_x, 0)
        self.reassign_cluster_id(collagen_upper_x_left, 0)
        self.reassign_cluster_id(collagen_upper_y, 0)
        self.reassign_cluster_id(collagen_upper_y_left, 0)
                 
        #Create all lower track elements
        collagen_lower_fixed = self.new_cell(self.typeCollagen) #Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2-fixed_height//2, 0] = collagen_lower_fixed
        collagen_lower_x = self.new_cell(self.typeCollagen) #Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-lower_x:self.dim.x-fixed_width, self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_x
        collagen_lower_x_left = self.new_cell(self.typeCollagen) #Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-lower_x, self.dim.y//2-fixed_height//2, 0] = collagen_lower_x_left
        #Distinct between a narrowing and a widening
        if lower_y > 0:
            collagen_lower_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2-fixed_height//2-lower_y:self.dim.y//2-fixed_height//2, 0] = collagen_lower_y
            collagen_lower_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-lower_x, self.dim.y//2-fixed_height//2-lower_y:self.dim.y//2-fixed_height//2, 0] = collagen_lower_y_left
        else:
            collagen_lower_y = self.new_cell(self.typeCollagen) # Vertical element at the start of the narrowing=≠≠
            self.cell_field[self.dim.x-fixed_width, self.dim.y//2-fixed_height//2:self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_y
            collagen_lower_y_left = self.new_cell(self.typeCollagen) # Vertical element at the end of the narrowing
            self.cell_field[self.dim.x-fixed_width-lower_x, self.dim.y//2-fixed_height//2:self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_y_left	  
        #Assign the same cluster id to all lower track elements
        self.reassign_cluster_id(collagen_lower_fixed, 1)
        self.reassign_cluster_id(collagen_lower_x, 1)
        self.reassign_cluster_id(collagen_lower_x_left, 1)
        self.reassign_cluster_id(collagen_lower_y, 1)
        self.reassign_cluster_id(collagen_lower_y_left, 1)
            
    def DiagonalCollagenCreator(self):	
        #Set all dimensions
        fixed_width = 100
        fixed_height = 50
        upper_x = 100
        upper_y = -10
        lower_x = 100
        lower_y = -10
        
        #Create all upper track elements
        collagen_upper_fixed = self.new_cell(self.typeCollagen) #Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2+fixed_height//2, 0] = collagen_upper_fixed
        collagen_upper_x = self.new_cell(self.typeCollagen) #Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-upper_x:self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y, 0] = collagen_upper_x
        collagen_upper_x_left = self.new_cell(self.typeCollagen) #Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-upper_x-10, self.dim.y//2+fixed_height//2, 0] = collagen_upper_x_left
        collagen_upper_y = self.new_cell(self.typeCollagen) #Vertical element at the start of the narrowing
        self.cell_field[self.dim.x-fixed_width, self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2, 0] = collagen_upper_y
        #Create all steps at the end of the narrowing
        collagen_upper_step1 = self.new_cell(self.typeCollagen) 
        self.cell_field[self.dim.x-fixed_width-upper_x-2:self.dim.x-fixed_width-upper_x,self.dim.y//2+fixed_height//2+upper_y:self.dim.y//2+fixed_height//2+upper_y+2,0] = collagen_upper_step1
        collagen_upper_step2 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-4:self.dim.x-fixed_width-upper_x-2,self.dim.y//2+fixed_height//2+upper_y+2:self.dim.y//2+fixed_height//2+upper_y+4,0] = collagen_upper_step2
        collagen_upper_step3 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-6:self.dim.x-fixed_width-upper_x-4,self.dim.y//2+fixed_height//2+upper_y+4:self.dim.y//2+fixed_height//2+upper_y+6,0] = collagen_upper_step3
        collagen_upper_step4 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-8:self.dim.x-fixed_width-upper_x-6,self.dim.y//2+fixed_height//2+upper_y+6:self.dim.y//2+fixed_height//2+upper_y+8,0] = collagen_upper_step4
        collagen_upper_step5 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-upper_x-10:self.dim.x-fixed_width-upper_x-6,self.dim.y//2+fixed_height//2+upper_y+8:self.dim.y//2+fixed_height//2+upper_y+10,0] = collagen_upper_step5
        #Assign the same cluster id to all upper track elements
        self.reassign_cluster_id(collagen_upper_fixed, 0)
        self.reassign_cluster_id(collagen_upper_x, 0)
        self.reassign_cluster_id(collagen_upper_x_left, 0)
        self.reassign_cluster_id(collagen_upper_y, 0)
        self.reassign_cluster_id(collagen_upper_step1, 0)
        self.reassign_cluster_id(collagen_upper_step2, 0)
        self.reassign_cluster_id(collagen_upper_step3, 0)
        self.reassign_cluster_id(collagen_upper_step4, 0)
        self.reassign_cluster_id(collagen_upper_step5, 0)
        
        #Create all lower track elements
        collagen_lower_fixed = self.new_cell(self.typeCollagen) #Horizontal element before narrowing
        self.cell_field[self.dim.x-fixed_width:self.dim.x, self.dim.y//2-fixed_height//2, 0] = collagen_lower_fixed
        collagen_lower_x = self.new_cell(self.typeCollagen) #Horizontal element of narrowing
        self.cell_field[self.dim.x-fixed_width-lower_x:self.dim.x-fixed_width, self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_x
        collagen_lower_x_left = self.new_cell(self.typeCollagen) #Horizontal element after narrowing
        self.cell_field[0:self.dim.x-fixed_width-lower_x-10, self.dim.y//2-fixed_height//2, 0] = collagen_lower_x_left
        collagen_lower_y = self.new_cell(self.typeCollagen) #Vertical element at the start of the narrowing
        self.cell_field[self.dim.x-fixed_width, self.dim.y//2-fixed_height//2:self.dim.y//2-fixed_height//2-lower_y, 0] = collagen_lower_y
        #Create all steps at the end of the narrowing 
        collagen_lower_step1 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-2:self.dim.x-fixed_width-lower_x,self.dim.y//2-fixed_height//2-lower_y-2:self.dim.y//2-fixed_height//2-lower_y,0] = collagen_lower_step1
        collagen_lower_step2 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-4:self.dim.x-fixed_width-lower_x-2,self.dim.y//2-fixed_height//2-lower_y-4:self.dim.y//2-fixed_height//2-lower_y-2,0] = collagen_lower_step2
        collagen_lower_step3 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-6:self.dim.x-fixed_width-lower_x-4,self.dim.y//2-fixed_height//2-lower_y-6:self.dim.y//2-fixed_height//2-lower_y-4,0] = collagen_lower_step3
        collagen_lower_step4 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-8:self.dim.x-fixed_width-lower_x-6,self.dim.y//2-fixed_height//2-lower_y-8:self.dim.y//2-fixed_height//2-lower_y-6,0] = collagen_lower_step4
        collagen_lower_step5 = self.new_cell(self.typeCollagen)
        self.cell_field[self.dim.x-fixed_width-lower_x-10:self.dim.x-fixed_width-lower_x-6,self.dim.y//2-fixed_height//2-lower_y-10:self.dim.y//2-fixed_height//2-lower_y-8,0] = collagen_lower_step5
        #Assign the same cluster id to all lower track elements
        self.reassign_cluster_id(collagen_lower_fixed, 1)
        self.reassign_cluster_id(collagen_lower_x, 1)
        self.reassign_cluster_id(collagen_lower_x_left, 1)
        self.reassign_cluster_id(collagen_lower_y, 1)
        self.reassign_cluster_id(collagen_lower_step1, 1)
        self.reassign_cluster_id(collagen_lower_step2, 1)
        self.reassign_cluster_id(collagen_lower_step3, 1)
        self.reassign_cluster_id(collagen_lower_step4, 1)
        self.reassign_cluster_id(collagen_lower_step5, 1)
       
    def drawDDA(self,x1,y1,z1,x2,y2,z2):
        pixList=[]
        x,y,z = x1,y1,z1
        length = max(abs(x2-x1),abs(y2-y1),abs(z2-z1))
        dx = (x2-x1)/float(length)
        dy = (y2-y1)/float(length)
        dz = (z2-z1)/float(length)
        pixList.append((int(x),int(y),int(z)))
        for i in range(abs(length)):
            x += dx
            y += dy
            z += dz
            pixList.append((int(x),int(y),int(z)))
        return pixList
    
    def CollagenFibers(self):
        #Parameters for generating the fibers
        lx = self.dim.x #Window x width
        ly = self.dim.y #Window y width
        lz = self.dim.z #Window z width
        v = 100  #Number of fibers 
        fl = 100. #Length of the fibers in pixels
        
        #For every number in the number of fibers, now create a fiber        
        for i in range(v):
            cell = self.new_cell(self.COLLAGEN)  #Create a new cell for this fiber
            pixList = []
            m = int(lx*random.random())
            n = int(ly*random.random())
            p = int(lz*random.random())
            theta = 2*math.pi*random.random()
            phi = 2*math.pi*random.random()
            x = int(m+fl*math.sin(phi)*math.cos(theta))
            y = int(n+fl*math.sin(phi)*math.sin(theta))
            z = int(p+fl*math.cos(phi))
            print(i, x,m, y,n, z,p)
            pixList = self.drawDDA(x,y,z, m,n,p)
            if len(pixList) > 0:
                for (px,py,pz) in pixList:
                    px = min(max(px,0),lx-1)  #0<=px<=lx-1
                    py = min(max(py,0),ly-1)  #0<=py<=ly-1
                    pz = min(max(pz,0),lz-1)  #0<=pz<=lz-1
                    self.cell_field[px:px+1, py:py+1, pz:pz+1] = cell #Add this pixel to the cell
            cell.targetVolume = cell.volume  #The .xml says this cell type is frozen, 
            cell.lambdaVolume = 10000        #So this doesn't matter
    
    #Create various tracks with different dimensions
    def CollagenTrack(self, tracknumber):
        #y values may not exceed 55
        #x values may not exceed 300
        #Input are the dimensions of the narrowing = upper_x,upper_y,lower_x,lower_y 
        
        # Straight tube
        if tracknumber == 1: 
            self.CollagenCreator(0,0,0,0)
        # Upper indent
        elif tracknumber == 2:
            self.CollagenCreator(100,-30,0,0)
        # Lower indent
        elif tracknumber == 3:
            self.CollagenCreator(0,0,100,-12)
        # Upper and lower indent
        elif tracknumber == 4:
            self.CollagenCreator(150,-10,150,-10)
        # Upper and lower indent shifted
        elif tracknumber == 5:
            self.CollagenCreator(100,-12,150,-12)
        # Sharp upper and lower indent
        elif tracknumber == 6:
            self.CollagenCreator(10,-15,10,-15)
        # Broadening
        elif tracknumber == 7:
            self.CollagenCreator(300,5,300,5)
        # Diagonal version of track 4
        elif tracknumber == 8:
            self.DiagonalCollagenCreator()
        elif tracknumber == 9:
            self.CollagenFibers()   
            
    def start(self):
        #Create a collagen track
        self.CollagenTrack(9) #Adjustable
        
        #Note the tumor and nucleus need to be created after the collagen to prevent the cell cluster and collagen cluster to coincide
            
        # Create the tumor
        tumor = self.new_cell(self.TUMOR)
        tumor.targetVolume = self.tumorTargetVolume
        tumor.lambdaVolume = self.tumorLambdaVolume
        self.cell_field[50, self.dim.y//2, self.dim.z//2] = tumor
        self.myTumor = tumor
    
    #Occasionally generate chemical "pulses" that make the cell form protrusions
    def step(self, mcs):
        if mcs > 50: # Wait for some initial delay to give the cell time to form
            pulse_delay = 150 # Number of MC steps between each protrusion-generating pulse
            pulse_strength = 10000 # Strength of the chemical pulse
            pulse_distance = 7 # Maximum number of pixels away from the cell's COM that the pulse should be generated
            max_angle = 0.1 # Max angle of the offset vector relative to the x-axis (lower this value to get more protrusions to the right rather than up/down)
    
            if mcs % pulse_delay == 0:
                COM = np.array([self.myTumor.xCOM, self.myTumor.yCOM, self.myTumor.zCOM]) # Center of mass of the cell
                boundary_list = self.get_cell_boundary_pixel_list(self.myTumor) # List of all boundary pixels of the cell

                #Get the pixel of the cell that is the furthest to the right
                pixel_list = list(self.get_cell_pixel_list(self.myTumor)) # This list is sorted by x-coordinate
                # ^ This could also use get_cell_boundary_pixel_list instead; that might take less memory, but slightly more processing time
                
                # Fastest method: just pick the last pixel (with biggest x-coord)
                # Problem: this is also the pixel with greatest y, so pulses are biased to spawn further up
                #furthest_pixel = pixel_list[-1].pixel
                #furthest_pos = [furthest_pixel.x, furthest_pixel.y, furthest_pixel.z]
                
                # Less biased method: of all pixels with highest x, take the average of the highest and lowest y and z
                i = 1
                pixel_data = pixel_list[-1] # of all pixels with highest x, this is the one with highest y and z
                furthest_x = pixel_data.pixel.x
                y1 = pixel_data.pixel.y
                z1 = pixel_data.pixel.z
                # Keep going down the list until we encounter a pixel that no longer has highest x
                while pixel_data.pixel.x == furthest_x:
                    i += 1
                    pixel_data = pixel_list[-i]
                pixel_data = pixel_list[-i+1] # of all pixels with highest x, this is the one with lowest y and z
                y2 = pixel_data.pixel.y
                z2 = pixel_data.pixel.z
                furthest_y = int((y1+y2)/2) # take the average of highest and lowest y
                furthest_z = int((z1+z2)/2) # take the average of highest and lowest z
                furthest_pos = [furthest_x, furthest_y, furthest_z]
            
                rand_angle = random.uniform(-max_angle, max_angle)
                offset = pulse_distance * np.array([np.cos(rand_angle), np.sin(rand_angle),np.tan(rand_angle)])
                pulse_pos = np.floor(furthest_pos + offset)
                self.field.ChemField[pulse_pos[0], pulse_pos[1], pulse_pos[2]] = pulse_strength # Generate a pulse at furthest pixel position + offset in the direction of the external potential
            
    #Compute the total target volume of a given cell type
    def totalTargetVolumeByCell(self, type):
        totalVolume = 0
        for cell in self.cell_list_by_type(type):
            totalVolume += cell.targetVolume
        return totalVolume 
            
    #Compute the total target volume of a given cell type within a cluster
    def totalTargetVolumeByCellGivenClusters(self, type, clusterSet):
        totalVolumeArray = [0] * (len(clusterSet))
        for cell in self.cell_list_by_type(type):
            totalVolumeArray[cell.clusterId] += cell.targetVolume
        return totalVolumeArray
                    
    def on_stop(self):
        #Debug statement
        self.printLog()
        self.printLog('Cell list when stopped')
        self.printLog('type, cluster id, target volume')
        for cell in self.cell_list:
            self.printLog(self.typeToName(cell.type), cell.clusterId, cell.targetVolume)
        self.printLog()
        self.printLog('Steppable is stopped')
        self.myFile.close()
        return
    
    def finish(self):
        self.printLog('Steppable is finished')
        self.myFile.close()
        return

