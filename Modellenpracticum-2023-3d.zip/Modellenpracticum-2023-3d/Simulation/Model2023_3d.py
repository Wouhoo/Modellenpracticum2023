from cc3d import CompuCellSetup

from Model2023Steppables_3d import Model2023Steppable

CompuCellSetup.register_steppable(steppable=Model2023Steppable(frequency=1))

CompuCellSetup.run()