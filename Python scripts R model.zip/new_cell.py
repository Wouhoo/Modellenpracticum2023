import numpy

## An attempt to fix the old model that only made things 1000× worse.

class Cell:
	def __init__(self, 
	      point_amount: int = 8, 
		  point_locations: list = None, 
		  drift: list = [0.5, 0],
		  tensionrate: float = 0.1, 
		  volumemodifier: float = 0.2, 
		  contractionresistance: float = 0.5,
		  protrusion_rate_factor: float = 5,
		  force_rate_factor: float = 10,
		  nucleus_factor: float = 10,
		  size_nucleus: float = .2,
		  size_protrusions: float = .2,
		  speed_points: float = .8,
		  stick_rate: float = 1.0) -> None:
		"""
		Create a cell model.
		point_amount: int = Number of points to model.
		point_locations: None or List =	
			If None, will spread the points evenly on a unit circle around (0, 0)
			If List, must be 3 length list of the form: [x_cords list, y_cords list, [center_x, center_y]]
		tensionrate = tension will be multiplied by this factor before being added to energy. Higher: tension more important.
		volumemodifier = how hard it will be to gain volume. Multiplicative.
		contractionresistance = how hard it will be to reduce volume below the starting volume. Multiplicative.
		protrusion_rate, force_rate, nucleus_factor: Mulitplicative factors contributing to force.
		"""
		#Setup points
		self.point_amount 	= point_amount
		if point_locations:
			self.points_x		 = point_locations[0]
			self.points_y		 = point_locations[1]
			self.center_location = point_locations[2]
		else:
			self.points_x		 = [numpy.cos(2*numpy.pi*i/point_amount) for i in range(point_amount)]
			self.points_y		 = [numpy.sin(2*numpy.pi*i/point_amount) for i in range(point_amount)]
			self.center_location = [0, 0]

		#Setup modifiers
		self.drift					= drift
		self.tensionrate		    = tensionrate
		self.volumemodifier 	    = volumemodifier
		self.contractionresistance  = contractionresistance
		self.protrusion_rate_factor	= protrusion_rate_factor
		self.force_rate_factor		= force_rate_factor
		self.nucleus_factor			= nucleus_factor
		self.size_nucleus			= size_nucleus
		self.size_protrusions		= size_protrusions
		self.speed_points			= speed_points
		self.stick_rate				= stick_rate
		
		#Setup base values
		self.base_volume  = self.calculate_volume()
		self.base_tension = self.calculate_tension()
		self.energy 	  = 1.0
		self.stick_times  = [0] * self.point_amount
		
		#All done!
		return
	

	def get_angles(self) -> list:
		"Generate a list of angles of the cell object."
		point_angles = []
		for i in range(self.point_amount):
			point_angles += [numpy.angle(complex(self.points_x[i] - self.center_location[0], self.points_y[i] - self.center_location[1]))]
		return point_angles
	

	def check_center(self, points_x: list = None, points_y: list = None, center_location: list = None) -> bool:
		"""
		Checks the center of the cell.
		points_x, points_y, center_location: 
			None or list. If None, will use points_x (points_y) of the cell object;
			Else, will use the provided list.

		Returns False if one of the angles between points is either negative or too big (greater than pi).
		"""
		if points_x is None: points_x = self.points_x
		if points_y is None: points_y = self.points_y
		if center_location is None: center_location = self.center_location

		angles  = self.get_angles()
		index   = numpy.argmin(angles)
		if angles[index] > numpy.pi: return False
		
		for i in range(self.point_amount - 1):
			current = (i + index) % self.point_amount
			last = (i + index + 1) % self.point_amount
			if angles[last] - angles[current] > numpy.pi or angles[last] < angles[current]: return False

		if angles[(index - 1) % self.point_amount] < angles[index]: return False
		return True


	def calculate_volume(self, points_x: list = None, points_y: list = None, center_location: list = None) -> float:
		"""Calculate the volume of the cell.
		points_x, points_y, center_location: 
			None or list. If None, will use points_x (points_y) of the cell object;
			Else, will use the provided list.
		"""
		volume = 0
		if points_x is None: points_x = self.points_x
		if points_y is None: points_y = self.points_y
		if center_location is None: center_location = self.center_location

		for i in range(self.point_amount - 1):
			volume += abs((points_x[i]-center_location[0]) *(points_y[i+1]-center_location[1]) - (points_x[i+1]-center_location[0])*(points_y[i]-center_location[1]))
		volume 	   += abs((points_x[-1]-center_location[0])*(points_y[0]-center_location[1])   - (points_x[0]-center_location[0])*(points_y[-1]-center_location[1]))
		return volume / 2
	

	def calculate_tension(self, points_x: list = None, points_y: list = None, center_location: list = None) -> float:
		"""Calculate the energy of the cell.
		points_x, points_y, center_location: 
			None or list. If None, will use points_x (points_y) of the cell object;
			Else, will use the provided list.
		"""
		if points_x is None: points_x = self.points_x
		if points_y is None: points_y = self.points_y
		if center_location is None: center_location = self.center_location

		return (sum([(points_x[i] - center_location[0])**2 for i in range(self.point_amount)]) + 
				sum([(points_y[i] - center_location[1])**2 for i in range(self.point_amount)]))
	

	def calculate_energy(self, points_x: list = None, points_y: list = None, center_location: list = None) -> float:
		"""Calculate the energy of the cell.
		points_x, points_y, center_location: 
			None or list. If None, will use points_x (points_y) of the cell object;
			Else, will use the provided list.
		"""
		if points_x is None: points_x = self.points_x
		if points_y is None: points_y = self.points_y
		if center_location is None: center_location = self.center_location

		new_volume = self.calculate_volume(points_x, points_y, center_location)
		new_tension = self.calculate_tension(points_x, points_y, center_location)
		if new_volume >= self.base_volume: 
			self.energy = numpy.exp(self.volumemodifier*(new_volume/self.base_volume - 1))
		else: 
			self.energy = numpy.exp(self.contractionresistance*(self.base_volume/new_volume - 1))
		self.energy += self.tensionrate * abs(self.base_tension - new_tension)
		return self.energy
	
	
	def calculate_gradient(self, delta: int = 100):
		base_energy = self.calculate_energy()
		delta_x = numpy.mean([abs(self.points_x[i] - self.center_location[0]) for i in range(self.point_amount)]) / delta
		delta_y = numpy.mean([abs(self.points_y[i] - self.center_location[0]) for i in range(self.point_amount)]) / delta
		grad_x, grad_y = [], []

		for i in range(self.point_amount):
			new_x     = numpy.copy(self.points_x)
			new_x[i] += delta_x
			grad_x   += [(self.calculate_energy(points_x=new_x) - base_energy) / delta_x]
			new_y     = numpy.copy(self.points_y)
			new_y[i] += delta_y
			grad_y   += [(self.calculate_energy(points_y=new_y) - base_energy) / delta_y]

		dc = numpy.sqrt(delta_x**2 + delta_y**2)
		grad_x += [(self.calculate_energy(center_location=[self.center_location[0] + dc, self.center_location[1]]) - base_energy) / dc]
		grad_y += [(self.calculate_energy(center_location=[self.center_location[0], self.center_location[1] + dc]) - base_energy) / dc]

		return numpy.transpose(numpy.matrix([grad_x, grad_y]))


	def tick(self):
		force_vector 	= -self.calculate_gradient()
		force 			= numpy.sqrt(numpy.square(force_vector) * numpy.matrix([[1]]*(2)))
		force_rate 		= self.force_rate_factor * (sum(force[0:self.point_amount]) + self.nucleus_factor*force[-1])[0, 0]
		force[-1]	   *= self.nucleus_factor

		protrusion_rate  = [self.points_x[i] * self.drift[0] + self.points_y[i] * self.drift[1] for i in range(self.point_amount)] 
		protrusion_rate  = (protrusion_rate - min(protrusion_rate))**2 #very low on wrong side of cell
		protrusion_rate *= self.protrusion_rate_factor / max(protrusion_rate)

		delta_t = numpy.random.exponential(size = None, scale=1/(sum(protrusion_rate) + force_rate))

		if numpy.random.uniform() < force_rate / (sum(protrusion_rate) + force_rate):
			index_probabilities		 = force[:]
			index_probabilities[-1] *= self.nucleus_factor
			index_probabilities      = force.A1 / sum(force.A1)		#You wouldn't even begin to understand how much headache this cause me. ~Saya.
			index = numpy.random.choice(range(self.point_amount+1), p = index_probabilities)
			
			if index < self.point_amount:
				new_x = numpy.copy(self.points_x)
				new_y = numpy.copy(self.points_y)
				new_x[index] += self.speed_points * force_vector[index, 0]
				new_y[index] += self.speed_points * force_vector[index, 1]
				if numpy.random.uniform() < self.calculate_energy()/self.calculate_energy(new_x, new_y) and self.check_center(new_x, new_y):
					self.points_x = new_x
					self.points_y = new_y
					#Make new plot
					"""
					dev.off(dev.cur())
					plot(c(X,X[1]),c(Y,Y[1]),xlim=c(-5,5), ylim=c(-5,5),type='l',xlab='',ylab='')
					points(center[1],center[2])
					Sys.sleep(0.4)
					count_nucl=count_nucl+1
					current_energy=energy(X,Y,center)
					"""
			
			else:
				new_center = [self.center_location[i] + self.size_nucleus * force_vector[-1,i] for i in range(2)]
				if numpy.random.uniform() < self.calculate_energy()/self.calculate_energy(center_location=new_center) and self.check_center(center_location=new_center):
					self.center_location = new_center
					# Make plot
					"""
					dev.off(dev.cur())
					plot(c(X,X[1]),c(Y,Y[1]),xlim=c(-5,5),type='l', ylim=c(-5,5),xlab='',ylab='')
					points(center[1],center[2])
					Sys.sleep(0.4)
					count_nucl=count_nucl+1
					current_energy=energy(X,Y,center)
					"""
				pass
		else:
			index = numpy.random.choice(range(self.point_amount), p = protrusion_rate / sum(protrusion_rate))
			if self.stick_times[index] <= 0:
				phi = numpy.random.uniform() * 2 * numpy.pi
				t_distribution = numpy.random.standard_t(df = 3)
				jump = [self.drift[0] + numpy.cos(phi) * t_distribution * self.size_protrusions, 
						self.drift[1] + numpy.sin(phi) * t_distribution * self.size_protrusions]
				new_x = numpy.copy(self.points_x)
				new_y = numpy.copy(self.points_y)
				new_x[index] += jump[0]
				new_y[index] += jump[1]
				if numpy.random.uniform() < self.calculate_energy()/self.calculate_energy(new_x, new_y) and self.check_center(new_x, new_y):
					self.points_x = new_x
					self.points_y = new_y
					self.stick_times[index] = numpy.random.gamma(shape = 3, scale = 1/self.stick_rate)
					# Make plot
					"""
					dev.off(dev.cur())
					plot(c(X,X[1]),c(Y,Y[1]),xlim=c(-5,5), ylim=c(-5,5),type='l',xlab='',ylab='')
					points(center[1],center[2])
					Sys.sleep(0.4)
					count_prot=count_prot+1
					current_energy=energy(X,Y,center)
					"""




def main():
	"Testing purposes."
	import matplotlib.pyplot as plot
	my_cell = Cell(8)
	print(my_cell.points_x)
	plot.plot(my_cell.points_x + [my_cell.points_x[0]], my_cell.points_y + [my_cell.points_y[0]], c = "m")
	plot.scatter(my_cell.center_location[0], my_cell.center_location[1])
	#plot.show()

	print(my_cell.get_angles())
	print(my_cell.calculate_volume())
	print(my_cell.calculate_tension())

	print(my_cell.calculate_energy())

	print(-my_cell.calculate_gradient())
	print(numpy.sqrt(numpy.square(-my_cell.calculate_gradient()) * numpy.matrix([[1]]*(2))))

	Cell.tick(my_cell)

if __name__ == "__main__":
	main()