import matplotlib.pyplot as plot
import numpy


n_radii = 8
n_angles = 36

# Make radii and angles spaces (radius r=0 omitted to eliminate duplication).
radii = numpy.linspace(0.125, 1.0, n_radii)
angles = numpy.linspace(0, 2*numpy.pi, n_angles, endpoint=False)[..., numpy.newaxis]

# Convert polar (radii, angles) coords to cartesian (x, y) coords.
# (0, 0) is manually added at this stage,  so there will be no duplicate
# points in the (x, y) plane.
x = numpy.append(0, (radii*numpy.cos(angles)).flatten())
y = numpy.append(0, (radii*numpy.sin(angles)).flatten())

# Compute z to make the pringle surface.
z = numpy.sin(-x*y)

ax = plot.figure().add_subplot(projection='3d')

print(f"x: {len(x)}, y: {len(y)}, z: {len(z)}")

ax.plot_trisurf(x, y, z, linewidth=0.2, antialiased=True)

plot.show()