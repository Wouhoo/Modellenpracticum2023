
n=8 #number of possible protusion points

x
X=rep(n,0)
Y=rep(n,0)

for (i in 1:n){
  X[i]=cos(2*pi*i/n)
  Y[i]=sin(2*pi*i/n)
}

plot(c(X,X[1]),c(Y,Y[1]),xlim=c(-5,5), ylim=c(-5,5),type='l',xlab='',ylab='')

center=c(0,0)
points(center[1],center[2])
Sys.sleep(0.4)

get.angles = function(X,Y,center){
  foo=cbind(X-center[1],Y-center[2])
  angles=atan(foo[,2]/foo[,1])
  angles[foo[,1]<0 & foo[,2]>0]=angles[foo[,1]<0 & foo[,2]>0]+pi
  angles[foo[,1]<0 & foo[,2]<0]=angles[foo[,1]<0 & foo[,2]<0]+pi
  angles[foo[,1]>0 & foo[,2]<0]=angles[foo[,1]>0 & foo[,2]<0]+2*pi
  return(angles)
}


check.centre = function(X,Y,center){
  angles=get.angles(X,Y,center)
  index=which.min(angles)
  check=TRUE
  n=length(X)
  if (angles[index]>pi) check=FALSE
  first=index
  for (i in 1:(n-1)){
    if (first+1>8) {last=1} else {last=first+1}
    # Moet 8 hier niet n zijn?
    if ((angles[last]-angles[first]>pi) | (angles[last]<angles[first])) check=FALSE
    first=last
  }
  if (angles[first]-angles[index]<pi) check=FALSE
  return(check)
}

volume = function(X,Y,center){
  n=length(X)
  volume=0
  for (i in 1:(n-1)){
    volume=volume+abs((X[i]-center[1])*(Y[i+1]-center[2]) - (X[i+1]-center[1])*(Y[i]-center[2]))
  }
  volume=volume+abs((X[n]-center[1])*(Y[1]-center[2]) - (X[1]-center[1])*(Y[n]-center[2]))
  return(volume/2)
}

tension = function(X,Y,center){
  return(sum((X-center[1])^2)+sum((Y-center[2])^2))
}

energy = function(X,Y,center){
  energy=1
  vol=volume(X,Y,center)
  tens=tension(X,Y,center)
  if (vol>vol0) energy=exp(lambda1*(vol/vol0 -1))
  if(vol<vol0) energy =exp(lambda2*(vol0/vol -1))
  energy=energy+alpha*abs(tens-tension0)
  return(energy)
}

grad.energy = function(X,Y,center){
  n=length(X)
  grad=cbind(rep(0,n+1),rep(0,n+1))
  dx=mean(abs(X-center[1]))/100
  dy=mean(abs(Y-center[2]))/100
  for (i in 1:n){
    Xfoo=X
    Xfoo[i]=X[i]+dx
    Yfoo=Y
    Yfoo[i]=Y[i]+dy
    grad[i,1]=(energy(Xfoo,Y,center) - energy(X,Y,center))/dx
    grad[i,2]=(energy(X,Yfoo,center) - energy(X,Y,center))/dy
  }
  dc=sqrt(dx^2+dy^2)
  grad[n+1,1]=(energy(X,Y,center+c(dc,0)) - energy(X,Y,center))/dc
  grad[n+1,2]=(energy(X,Y,center+c(0,dc)) - energy(X,Y,center))/dc
  return(grad)
}




h=c(0.5,0) #drift to the right (if positive)
alpha=0.1 #importance of tension (higher, more important)
lambda1=0.2 #how difficult is it to increase volume
lambda2=0.5 #more difficult to shrink below vol0 when high
prot_rate_factor = 5 #protrusion rate
force_rate_fact = 10 #rate factor due to force
nuc_fact=10 #more updates for nucleus
sd_nucl=0.2 #size of nucleus jumps
sd_prot=0.2 #size of protusions
sd_points=0.8 #speed of forced jumps

vol0=volume(X,Y,center)
tension0=tension(X,Y,center)

stick_times=rep(0,n) #times particles are stuck to surroundings
stick_rate=1 #low rate means particle stick longer

T=0
current_energy=1
count_nucl=0
count_prot=0

while (T<20){
  force_vec=-grad.energy(X,Y,center)
  force=sqrt(rowSums(force_vec^2))
  force_rate=force_rate_fact*(sum(force[1:n])+nuc_fact*force[n+1])
  
  #determine rate of protusions: higher in direction of h
  
  prot_rate = X*h[1]+Y*h[2]
  prot_rate = (prot_rate - min(prot_rate))^2 #very low on wrong side of cell
  prot_rate=prot_rate/max(prot_rate)
  prot_rate=prot_rate_factor*prot_rate
  
  
  dt=rexp(1,rate=sum(prot_rate)+force_rate)
  stick_times=stick_times-rep(dt,n)
  if (runif(1)<force_rate/(sum(prot_rate)+force_rate)){
    #the force is moving a point or the center
    index=sample(1:(n+1),1,prob=c(force[1:n],nuc_fact*force[n+1]))
    if (index<n+1){
      if (stick_times[index]<=0){
        Xnew=X
        Ynew=Y
        Xnew[index]=X[index]+sd_points*force_vec[index,1] #move in direction of force
        Ynew[index]=Y[index]+sd_points*force_vec[index,2]
        if (runif(1)<current_energy/energy(Xnew,Ynew,center) & check.centre(Xnew,Ynew,center)){
          X=Xnew
          Y=Ynew
          #stick_times[index]=rgamma(1,shape=3,rate=stick_rate)
          dev.off(dev.cur())
          plot(c(X,X[1]),c(Y,Y[1]),xlim=c(-5,5), ylim=c(-5,5),type='l',xlab='',ylab='')
          points(center[1],center[2])
          Sys.sleep(0.4)
          count_nucl=count_nucl+1
          current_energy=energy(X,Y,center)
        }
      }
    } else {
      center_new=center+sd_nucl*force_vec[n+1,]
      if (runif(1)<current_energy/energy(X,Y,center_new)){
        if (check.centre(X,Y,center_new)){
          center=center_new
          dev.off(dev.cur())
          plot(c(X,X[1]),c(Y,Y[1]),xlim=c(-5,5),type='l', ylim=c(-5,5),xlab='',ylab='')
          points(center[1],center[2])
          Sys.sleep(0.4)
          count_nucl=count_nucl+1
          current_energy=energy(X,Y,center)
        }
      }
    }
  } else {
    index=sample(1:n,1,prob=prot_rate)
    if (stick_times[index]<=0){
      phi=runif(1)*2*pi
      jump=h+c(cos(phi),sin(phi))*rt(1,3)*sd_prot
      Xnew=X
      Ynew=Y
      Xnew[index]=X[index]+jump[1]
      Ynew[index]=Y[index]+jump[2]
      if (runif(1)<current_energy/energy(Xnew,Ynew,center) & check.centre(Xnew,Ynew,center)){
        X=Xnew
        Y=Ynew
        stick_times[index]=rgamma(1,shape=3,rate=stick_rate)
        dev.off(dev.cur())
        plot(c(X,X[1]),c(Y,Y[1]),xlim=c(-5,5), ylim=c(-5,5),type='l',xlab='',ylab='')
        points(center[1],center[2])
        Sys.sleep(0.4)
        count_prot=count_prot+1
        current_energy=energy(X,Y,center)
      }
    }
  }
  T=T+dt
}





